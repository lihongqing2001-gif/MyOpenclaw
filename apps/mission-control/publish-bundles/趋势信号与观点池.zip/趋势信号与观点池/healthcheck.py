import json
from pathlib import Path


MANIFEST = json.loads(r'''{"id": "cap.openclaw.sop.x-01186f69", "name": "趋势信号与观点池", "version": "0.2.0", "description": "围绕一个关键词、人物、品牌或行业，持续整理 X 上的热门观点、争议点和可转化内容角度。", "domain": "社交媒体与内容", "category": "内容洞察", "tags": ["社交媒体与内容", "内容采集", "sop"], "ownership": "openclaw", "publish": "local-bundle", "dependencies": ["cap.openclaw.integration.x-twitter-skill"], "requires": ">=2026.3.2", "skills": ["skills/assistant-orchestrator/SKILL.md", "skills/social-content/SKILL.md", "skills/web-search-plus/SKILL.md"], "sops": ["sops/趋势信号与观点池.md"], "install": "python3 install.py", "healthcheck": "python3 healthcheck.py", "outputs": ["outputs/cap.openclaw.sop.x-01186f69/"], "packaged_capabilities": ["cap.openclaw.skill.assistant-orchestrator", "cap.openclaw.skill.social-content", "cap.openclaw.skill.web-search-plus"], "entrypoints": [{"label": "趋势信号与观点池", "command": "__OPENCLAW_WORKFLOW__ sop-x-趋势信号摘要与观点池"}]}''')


def main():
    workspace = Path.home() / ".openclaw" / "workspace"
    required = [
        workspace / "sops/趋势信号与观点池.md",
        workspace / "agents" / "knowledge" / "portable" / MANIFEST["id"],
        workspace / "portable-bundles" / MANIFEST["id"] / "bundle" / "capability-manifest.json",
    ]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise SystemExit("Missing required paths: " + ", ".join(missing))
    print(f"Healthcheck OK for {MANIFEST['id']}")


if __name__ == "__main__":
    main()
