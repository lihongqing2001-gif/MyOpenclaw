import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional


def normalize_key(value: str) -> str:
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", value.lower())


def is_shell_like_command(command: str) -> bool:
    normalized = command.strip()
    return (
        normalized.startswith("__OPENCLAW_WORKFLOW__")
        or
        normalized.startswith("/")
        or normalized.startswith("python ")
        or normalized.startswith("python3 ")
        or normalized.startswith("npm ")
        or normalized.startswith("node ")
        or normalized.startswith("uv ")
        or normalized.startswith("claw ")
    )


class OpenClawResidentAgent:
    def __init__(
        self,
        base_url: str = "http://127.0.0.1:3000",
        agent_id: str = "openclaw-resident-agent",
        heartbeat_interval: float = 5.0,
        poll_interval: float = 2.0,
        openclaw_agent_id: str = "engineer",
        whatsapp_target: Optional[str] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.heartbeat_interval = heartbeat_interval
        self.poll_interval = poll_interval
        self.openclaw_agent_id = openclaw_agent_id
        self.whatsapp_target = whatsapp_target
        self.running = True
        self.workspace_root = Path.home() / ".openclaw" / "workspace"
        self.knowledge_root = self.workspace_root / "agents" / "knowledge"

    def _post_json(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))

    def send_heartbeat(self) -> None:
        self._post_json(
            "/api/v1/heartbeat",
            {
                "agentId": self.agent_id,
            },
        )

    def poll_task(self) -> Optional[Dict[str, Any]]:
        response = self._post_json(
            "/api/v1/agent/poll",
            {
                "agentId": self.agent_id,
            },
        )
        return response.get("task")

    def update_task(
        self,
        task_id: str,
        status: str,
        node_status: str,
        result_summary: str,
        result_detail: Optional[str] = None,
        runtime_skills_used: Optional[list[Dict[str, Any]]] = None,
        knowledge_payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        payload: Dict[str, Any] = {
            "agentId": self.agent_id,
            "taskId": task_id,
            "status": status,
            "nodeStatus": node_status,
            "resultSummary": result_summary,
        }
        if result_detail is not None:
            payload["resultDetail"] = result_detail
        if runtime_skills_used:
            payload["runtimeSkillsUsed"] = runtime_skills_used
        if knowledge_payload is not None:
            payload["knowledgeAction"] = "upsert"
            payload["knowledgePayload"] = knowledge_payload
        self._post_json("/api/v1/agent/task-update", payload)

    def build_knowledge_item(
        self,
        task: Dict[str, Any],
        command: str,
        output_excerpt: str,
        links: Optional[list[Dict[str, str]]] = None,
    ) -> Dict[str, Any]:
        task_suffix = task["id"].split("_", 1)[-1]
        node_label = task["nodeLabel"]
        return {
            "id": f"kb_runtime_{task_suffix}",
            "human": {
                "title": f"{node_label} 执行产物",
                "summary": f"Resident agent executed `{command}` and captured a runtime artifact.",
                "content_md": (
                    f"# {node_label} 执行结果\n\n"
                    f"- Command: `{command}`\n"
                    f"- Agent: `{self.agent_id}`\n"
                    f"- Result excerpt:\n\n```text\n{output_excerpt}\n```"
                ),
                "tags": ["runtime", "openclaw", node_label],
                "domain": "OpenClaw Runtime",
                "platform": "Resident Agent",
                "links": links or [],
            },
            "machine": {
                "intent": "workflow_runtime",
                "entities": {"nodeId": task["nodeId"]},
                "steps": [
                    "Claim queued task",
                    "Resolve command and inputs",
                    "Execute workflow handler",
                    "Report result back to UI",
                ],
                "commands": [command],
                "constraints": ["Resident agent loop", "Broker mediated"],
            },
        }

    def ensure_knowledge_dirs(self) -> None:
        for subdir in [
            "cases",
            "runtime-lessons",
            "skills",
            "sops",
            "confirmed",
        ]:
            (self.knowledge_root / subdir).mkdir(parents=True, exist_ok=True)

    def write_markdown_file(self, target: Path, content: str) -> None:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    def run_qmd_update(self) -> str:
        try:
            process = subprocess.run(
                ["qmd", "update"],
                cwd=str(self.workspace_root),
                capture_output=True,
                text=True,
                timeout=180,
            )
            output = "\n".join(
                part for part in [process.stdout.strip(), process.stderr.strip()] if part
            ).strip()
            return output or "qmd update completed."
        except Exception as error:
            return f"qmd update skipped: {error}"

    def write_case_note(
        self,
        task: Dict[str, Any],
        command: str,
        output_excerpt: str,
    ) -> Path:
        self.ensure_knowledge_dirs()
        target = self.knowledge_root / "cases" / f"{task['id']}.md"
        context = task.get("context") or {}
        content = f"""---
id: {task['id']}
type: case
evidence: runtime
node_id: {task['nodeId']}
updated_at: {time.strftime('%Y-%m-%dT%H:%M:%S%z')}
---

# {task['nodeLabel']} 运行案例

## Command

`{command}`

## Inputs

```json
{json.dumps(context.get('inputValues') or {}, ensure_ascii=False, indent=2)}
```

## Result

```text
{output_excerpt}
```
"""
        self.write_markdown_file(target, content)
        return target

    def write_runtime_lesson(
        self,
        task: Dict[str, Any],
        command: str,
        output_excerpt: str,
        reason: str,
    ) -> Path:
        self.ensure_knowledge_dirs()
        target = self.knowledge_root / "runtime-lessons" / f"{task['id']}.md"
        context = task.get("context") or {}
        content = f"""---
id: {task['id']}
type: runtime-lesson
evidence: runtime
node_id: {task['nodeId']}
updated_at: {time.strftime('%Y-%m-%dT%H:%M:%S%z')}
---

# {task['nodeLabel']} 运行教训

## Reason

{reason}

## Command

`{command}`

## Inputs

```json
{json.dumps(context.get('inputValues') or {}, ensure_ascii=False, indent=2)}
```

## Output

```text
{output_excerpt}
```
"""
        self.write_markdown_file(target, content)
        return target

    def parse_xiaohongshu_url(self, url: str) -> Dict[str, str]:
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        match = re.search(r"/explore/([^/?#]+)", parsed.path)
        if not match:
            raise ValueError("Could not extract feed_id from Xiaohongshu URL")
        feed_id = match.group(1)
        xsec_token = query.get("xsec_token", [""])[0]
        if not xsec_token:
            raise ValueError("Could not extract xsec_token from Xiaohongshu URL")
        return {"id": feed_id, "token": xsec_token}

    def build_input_aliases(self, task: Dict[str, Any]) -> Dict[str, str]:
        aliases: Dict[str, str] = {}
        context = task.get("context") or {}
        input_values = context.get("inputValues") or {}

        for raw_key, raw_value in input_values.items():
            if not isinstance(raw_value, str):
                continue
            value = raw_value.strip()
            if not value:
                continue
            aliases[normalize_key(raw_key)] = value

        note_url = next(
            (
                value
                for key, value in aliases.items()
                if "url" in key and "xiaohongshu" in value.lower()
            ),
            None,
        )
        if note_url:
            try:
                parsed = self.parse_xiaohongshu_url(note_url)
                aliases["id"] = parsed["id"]
                aliases["token"] = parsed["token"]
                aliases["feedid"] = parsed["id"]
                aliases["xsectoken"] = parsed["token"]
            except ValueError:
                pass

        return aliases

    def replace_placeholders(self, command: str, aliases: Dict[str, str]) -> str:
        shell_mode = not command.strip().startswith("/")

        def repl(match: re.Match[str]) -> str:
            key = normalize_key(match.group(1))
            value = aliases.get(key)
            if value is None:
                return match.group(0)
            return shlex.quote(value) if shell_mode else value

        return re.sub(r"<([^>]+)>", repl, command)

    def resolve_cwd(self, task: Dict[str, Any]) -> Optional[str]:
        context = task.get("context") or {}
        required_skills = context.get("requiredSkills") or []
        for module in required_skills:
            source_path = module.get("sourcePath")
            if source_path:
                return str(Path(source_path).parent)

        source_path = context.get("sourcePath")
        if source_path:
            return str(Path(source_path).parent)
        return None

    def infer_runtime_skills(
        self,
        task: Dict[str, Any],
        command: str,
        cwd: Optional[str],
    ) -> list[Dict[str, Any]]:
        context = task.get("context") or {}
        required_skills = context.get("requiredSkills") or []
        runtime_skills: list[Dict[str, Any]] = []

        cwd_path = Path(cwd).resolve() if cwd else None
        for module in required_skills:
            if not isinstance(module, dict):
                continue

            evidence = module.get("evidence")
            source_type = module.get("sourceType")
            source_path = module.get("sourcePath")
            label = module.get("label")

            confirmed = False
            if source_type == "skill" and source_path and cwd_path:
                skill_dir = Path(source_path).resolve().parent
                confirmed = cwd_path == skill_dir or skill_dir in cwd_path.parents
            elif source_type == "foundation" and evidence == "declared":
                confirmed = False
            elif label and label.lower() in command.lower():
                confirmed = True

            if confirmed:
                runtime_skills.append(
                    {
                        **module,
                        "evidence": "runtime",
                    }
                )

        return runtime_skills

    def normalize_shell_command(self, command: str) -> str:
        command = command.strip()
        if command.startswith("python "):
            return "python3 " + command[len("python ") :]
        return command

    def unresolved_placeholders(self, command: str) -> list[str]:
        return re.findall(r"<([^>]+)>", command)

    def run_shell_command(
        self,
        command: str,
        cwd: Optional[str],
    ) -> subprocess.CompletedProcess[str]:
        return self.run_subprocess(
            command,
            shell=True,
            cwd=cwd,
            timeout=600,
        )

    def run_subprocess(
        self,
        args: Any,
        *,
        shell: bool = False,
        cwd: Optional[str] = None,
        timeout: int = 600,
    ) -> subprocess.CompletedProcess[str]:
        process = subprocess.Popen(
            args,
            shell=shell,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        start = time.monotonic()
        next_heartbeat = start + self.heartbeat_interval

        while process.poll() is None:
            now = time.monotonic()
            if now >= next_heartbeat:
                try:
                    self.send_heartbeat()
                except Exception:
                    pass
                next_heartbeat = now + self.heartbeat_interval

            if now - start > timeout:
                process.kill()
                stdout, stderr = process.communicate()
                raise subprocess.TimeoutExpired(args, timeout, stdout, stderr)

            time.sleep(0.5)

        stdout, stderr = process.communicate()
        return subprocess.CompletedProcess(
            args=args,
            returncode=process.returncode or 0,
            stdout=stdout,
            stderr=stderr,
        )

    def run_openclaw_command(self, command: str) -> subprocess.CompletedProcess[str]:
        return self.run_subprocess(
            [
                "openclaw",
                "agent",
                "--agent",
                self.openclaw_agent_id,
                "--message",
                command,
                "--json",
                "--timeout",
                "120",
            ],
            timeout=180,
        )

    def detect_whatsapp_target(self) -> Optional[str]:
        if self.whatsapp_target:
            return self.whatsapp_target

        try:
            process = subprocess.run(
                ["openclaw", "directory", "self", "--channel", "whatsapp"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = "\n".join(part for part in [process.stdout, process.stderr] if part)
            match = re.search(r"\+\d{8,20}", output)
            if match:
                self.whatsapp_target = match.group(0)
        except Exception:
            self.whatsapp_target = None

        return self.whatsapp_target

    def send_whatsapp_message(self, message: str) -> None:
        target = self.detect_whatsapp_target()
        if not target:
            return

        subprocess.run(
            [
                "openclaw",
                "message",
                "send",
                "--channel",
                "whatsapp",
                "--target",
                target,
                "--message",
                message,
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )

    def analyze_openclaw_result(
        self, process: subprocess.CompletedProcess[str]
    ) -> tuple[bool, str]:
        stdout = (process.stdout or "").strip()
        stderr = (process.stderr or "").strip()
        combined = "\n".join(part for part in [stdout, stderr] if part).strip()

        try:
          data = json.loads(stdout) if stdout else {}
        except Exception:
          data = {}

        payload_texts: list[str] = []
        if isinstance(data, dict):
            payloads = (
                data.get("result", {}).get("payloads", [])
                if isinstance(data.get("result"), dict)
                else []
            )
            for payload in payloads:
                if isinstance(payload, dict) and payload.get("text"):
                    payload_texts.append(str(payload["text"]))

        text_blob = "\n".join(payload_texts + [combined]).lower()
        aborted = bool(data.get("result", {}).get("meta", {}).get("aborted")) if isinstance(data, dict) else False
        summary = str(data.get("summary", "")).lower() if isinstance(data, dict) else ""

        if process.returncode != 0:
            return False, combined or "OpenClaw command failed."
        if aborted:
            return False, combined or "OpenClaw task aborted."
        if "error occurred while processing your request" in text_blob:
            return False, combined or "OpenClaw upstream provider error."
        if "all models failed" in text_blob:
            return False, combined or "OpenClaw model routing failed."
        if summary and summary != "completed":
            return False, combined or f"OpenClaw returned summary={summary}."

        return True, combined or "OpenClaw task completed."

    def looks_like_bootstrap_reply(self, text: str) -> bool:
        lowered = text.lower()
        return any(
            token in lowered
            for token in [
                "bootstrap.md",
                "who am i",
                "what should i call you",
                "identity setup",
                "memory.md",
                "tell me these",
            ]
        )

    def build_openclaw_prompt(
        self,
        task: Dict[str, Any],
        command: str,
        cwd: Optional[str],
    ) -> str:
        context = task.get("context") or {}
        input_values = context.get("inputValues") or {}
        required_skills = context.get("requiredSkills") or []
        skill_labels = [
            skill.get("label")
            for skill in required_skills
            if isinstance(skill, dict) and skill.get("label")
        ]
        task_session = f"openclaw-web-task-{task['id']}"
        lines = [
            "SYSTEM TASK FROM OPENCLAW WEB CONTROL.",
            "Do not do bootstrap, identity setup, memory setup, or small talk.",
            "Treat this as an app-dispatched operational task.",
            f"Task session id: {task_session}",
            f"Node label: {task['nodeLabel']}",
            f"Command: {command}",
        ]
        if cwd:
            lines.append(f"Working directory: {cwd}")
        source_path = context.get("sourcePath")
        if source_path:
            lines.append(f"Primary reference document: {source_path}")
        if skill_labels:
            lines.append(f"Required skills: {', '.join(skill_labels)}")
        if input_values:
            lines.append(f"Input values: {json.dumps(input_values, ensure_ascii=False)}")
        lines.extend(
            [
                "If the command is a shell/python command, execute it with tools in the correct working directory.",
                "If the command begins with '/', treat it as an OpenClaw workflow command and solve it accordingly.",
                "If the command begins with '__OPENCLAW_WORKFLOW__', ignore the literal command string and instead use the source document plus input values to complete the workflow.",
                "When possible, produce the actual deliverable, not just advice.",
                "Return a concise human-readable execution summary with the real result.",
            ]
        )
        return "\n".join(lines)

    def run_openclaw_session_task(
        self,
        task: Dict[str, Any],
        command: str,
        cwd: Optional[str],
    ) -> subprocess.CompletedProcess[str]:
        target = self.detect_whatsapp_target()
        args = [
            "openclaw",
            "agent",
            "--agent",
            self.openclaw_agent_id,
            "--session-id",
            f"openclaw-web-task-{task['id']}",
            "--message",
            self.build_openclaw_prompt(task, command, cwd),
            "--json",
            "--timeout",
            "180",
        ]
        if target:
            args.extend(
                [
                    "--deliver",
                    "--reply-channel",
                    "whatsapp",
                    "--reply-to",
                    target,
                ]
            )

        return self.run_subprocess(args, timeout=240)

    def execute_task(self, task: Dict[str, Any]) -> None:
        task_id = task["id"]
        raw_command = task["command"]
        node_label = task["nodeLabel"]
        print(f"[agent] executing {node_label}: {raw_command}")
        self.update_task(
            task_id,
            status="running",
            node_status="running",
            result_summary=f"{node_label} is now running on {self.agent_id}.",
        )

        aliases = self.build_input_aliases(task)
        command = self.replace_placeholders(raw_command, aliases)
        cwd = self.resolve_cwd(task)

        unresolved = self.unresolved_placeholders(command)
        if unresolved:
            lesson_path = self.write_runtime_lesson(
                task,
                raw_command,
                f"Unresolved placeholders: {', '.join(unresolved)}",
                "missing-inputs",
            )
            qmd_result = self.run_qmd_update()
            self.update_task(
                task_id,
                status="failed",
                node_status="error",
                result_summary=f"{node_label} is missing required inputs: {', '.join(unresolved)}.",
                result_detail=(
                    "Fill the SOP input fields in the drawer before running this workflow. "
                    f"Unresolved placeholders: {', '.join(unresolved)}\n\n"
                    f"Knowledge note: {lesson_path}\n{qmd_result}"
                ),
                knowledge_payload=self.build_knowledge_item(
                    task,
                    raw_command,
                    f"Missing inputs: {', '.join(unresolved)}\nKnowledge note: {lesson_path}",
                    links=[{"title": lesson_path.name, "url": f"/api/v1/doc?path={urllib.parse.quote(str(lesson_path))}"}],
                ),
            )
            print(f"[agent] blocked {node_label}: missing inputs {unresolved}")
            return

        try:
            openclaw_process = self.run_openclaw_session_task(task, command, cwd)
        except subprocess.TimeoutExpired:
            self.update_task(
                task_id,
                status="failed",
                node_status="error",
                result_summary=f"{node_label} timed out during execution.",
                result_detail="The workflow exceeded the execution timeout.",
            )
            print(f"[agent] timeout {node_label}")
            return
        except Exception as error:
            self.update_task(
                task_id,
                status="failed",
                node_status="error",
                result_summary=f"{node_label} crashed before completion.",
                result_detail=str(error),
            )
            print(f"[agent] unexpected failure {node_label}: {error}")
            return

        openclaw_stdout = (openclaw_process.stdout or "").strip()
        openclaw_stderr = (openclaw_process.stderr or "").strip()
        openclaw_combined = "\n".join(
            part for part in [openclaw_stdout, openclaw_stderr] if part
        ).strip()
        openclaw_ok, openclaw_assessment = self.analyze_openclaw_result(
            openclaw_process
        )

        local_process: Optional[subprocess.CompletedProcess[str]] = None
        if (
            not openclaw_ok
            or self.looks_like_bootstrap_reply(openclaw_combined)
        ):
            try:
                if command.startswith("__OPENCLAW_WORKFLOW__"):
                    local_process = None
                elif command.startswith("/"):
                    local_process = self.run_openclaw_command(command)
                else:
                    local_process = self.run_shell_command(
                        self.normalize_shell_command(command),
                        cwd,
                    )
            except subprocess.TimeoutExpired:
                self.update_task(
                    task_id,
                    status="failed",
                    node_status="error",
                    result_summary=f"{node_label} timed out during fallback execution.",
                    result_detail=openclaw_combined[:3000] or "OpenClaw session fallback timed out.",
                )
                self.send_whatsapp_message(
                    f"[OpenClaw Web] {node_label} failed: fallback execution timed out."
                )
                return
            except Exception as error:
                self.update_task(
                    task_id,
                    status="failed",
                    node_status="error",
                    result_summary=f"{node_label} failed before fallback execution.",
                    result_detail=f"{openclaw_combined[:2000]}\n\nFallback error: {error}",
                )
                self.send_whatsapp_message(
                    f"[OpenClaw Web] {node_label} failed before fallback execution: {error}"
                )
                return

        process = local_process or openclaw_process
        runtime_skills_used = self.infer_runtime_skills(task, command, cwd)
        stdout = (process.stdout or "").strip()
        stderr = (process.stderr or "").strip()
        combined_output = "\n".join(part for part in [stdout, stderr] if part).strip()
        output_excerpt = combined_output[:3000] if combined_output else "No output captured."

        if local_process is None and not openclaw_ok:
            lesson_path = self.write_runtime_lesson(
                task,
                command,
                openclaw_assessment[:3000],
                "openclaw-session-failure",
            )
            qmd_result = self.run_qmd_update()
            self.update_task(
                task_id,
                status="failed",
                node_status="error",
                result_summary=f"{node_label} failed in OpenClaw session execution.",
                result_detail=f"{openclaw_assessment[:3000]}\n\nKnowledge note: {lesson_path}\n{qmd_result}",
                runtime_skills_used=runtime_skills_used,
                knowledge_payload=self.build_knowledge_item(
                    task,
                    command,
                    openclaw_assessment[:3000],
                    links=[{"title": lesson_path.name, "url": f"/api/v1/doc?path={urllib.parse.quote(str(lesson_path))}"}],
                ),
            )
            self.send_whatsapp_message(
                f"[OpenClaw Web] {node_label} failed.\n\n{openclaw_assessment[:1200]}"
            )
            print(f"[agent] failed {node_label}: openclaw session assessment")
            return

        if process.returncode != 0:
            lesson_path = self.write_runtime_lesson(
                task,
                command,
                output_excerpt,
                f"process-exit-{process.returncode}",
            )
            qmd_result = self.run_qmd_update()
            self.update_task(
                task_id,
                status="failed",
                node_status="error",
                result_summary=f"{node_label} failed with exit code {process.returncode}.",
                result_detail=f"{output_excerpt}\n\nKnowledge note: {lesson_path}\n{qmd_result}",
                runtime_skills_used=runtime_skills_used,
                knowledge_payload=self.build_knowledge_item(
                    task,
                    command,
                    output_excerpt,
                    links=[{"title": lesson_path.name, "url": f"/api/v1/doc?path={urllib.parse.quote(str(lesson_path))}"}],
                ),
            )
            self.send_whatsapp_message(
                f"[OpenClaw Web] {node_label} failed.\n\n{output_excerpt[:1200]}"
            )
            print(f"[agent] failed {node_label}: exit {process.returncode}")
            return

        case_path = self.write_case_note(task, command, output_excerpt)
        qmd_result = self.run_qmd_update()
        knowledge_item = self.build_knowledge_item(
            task,
            command,
            f"{output_excerpt}\n\nKnowledge note: {case_path}\n{qmd_result}",
            links=[{"title": case_path.name, "url": f"/api/v1/doc?path={urllib.parse.quote(str(case_path))}"}],
        )
        self.update_task(
            task_id,
            status="completed",
            node_status="idle",
            result_summary=f"{node_label} finished successfully.",
            result_detail=f"{output_excerpt}\n\nKnowledge note: {case_path}\n{qmd_result}",
            runtime_skills_used=runtime_skills_used,
            knowledge_payload=knowledge_item,
        )
        if local_process is not None:
            self.send_whatsapp_message(
                f"[OpenClaw Web] {node_label} completed via fallback execution.\n\n{output_excerpt[:1200]}"
            )
        print(f"[agent] completed {node_label}")

    def run(self) -> None:
        print(f"[agent] starting resident agent `{self.agent_id}` -> {self.base_url}")
        next_heartbeat_at = 0.0

        while self.running:
            now = time.monotonic()
            try:
                if now >= next_heartbeat_at:
                    self.send_heartbeat()
                    next_heartbeat_at = now + self.heartbeat_interval

                task = self.poll_task()
                if task is not None:
                    self.execute_task(task)
                    next_heartbeat_at = 0.0
                    continue
            except urllib.error.URLError as error:
                print(f"[agent] broker unavailable: {error}")
                next_heartbeat_at = 0.0
            except Exception as error:
                print(f"[agent] unexpected error: {error}")

            time.sleep(self.poll_interval)

        print("[agent] shutdown complete")

    def stop(self, *_args: Any) -> None:
        self.running = False


def main() -> int:
    agent = OpenClawResidentAgent(
        base_url=os.environ.get("OPENCLAW_BASE_URL", "http://127.0.0.1:3000"),
        agent_id=os.environ.get("OPENCLAW_AGENT_ID", "openclaw-resident-agent"),
        openclaw_agent_id=os.environ.get("OPENCLAW_EXECUTOR_AGENT", "engineer"),
        whatsapp_target=os.environ.get("OPENCLAW_WHATSAPP_TARGET"),
    )
    signal.signal(signal.SIGINT, agent.stop)
    signal.signal(signal.SIGTERM, agent.stop)
    agent.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
