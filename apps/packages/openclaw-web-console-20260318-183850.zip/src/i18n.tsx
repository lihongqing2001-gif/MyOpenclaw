import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

export type Language = "zh" | "en";

type Dictionary = Record<string, string>;

const LANGUAGE_STORAGE_KEY = "openclaw.ui.language";

const zh: Dictionary = {
  "header.status.linked": "AGENT 已连接",
  "header.status.waiting": "等待 AGENT",
  "header.theme.toggle": "切换明暗模式",
  "header.lang.toggle": "切换语言",
  "skip.main": "跳到主要内容",
  "dashboard.hero.title": "Spatial OS",
  "dashboard.hero.subtitle": "OpenClaw 数字工作台",
  "dashboard.tasks.title": "全局任务",
  "dashboard.tasks.live": "{count} 活跃",
  "dashboard.tasks.agent.online": "Resident Agent 在线",
  "dashboard.tasks.agent.waiting": "等待 Resident Agent",
  "dashboard.tasks.running": "运行中",
  "dashboard.tasks.queued": "队列中",
  "dashboard.tasks.recent": "最近结果",
  "dashboard.tasks.empty.running": "当前没有运行中的工作流。可以从技能树侧栏执行一个 SOP 进行测试。",
  "dashboard.tasks.empty.queue": "队列为空。",
  "dashboard.tasks.empty.recent": "最近的执行结果会显示在这里。",
  "dashboard.guide.title": "控制指南",
  "dashboard.guide.line1": "进入技能树后，点击节点主体打开侧栏，点击右侧 Chevron 展开下一级。",
  "dashboard.guide.line2": "每个层级都会显示最低技能模块；点击模块卡片可以查看安装命令与说明。",
  "dashboard.guide.line3": "运行 SOP 前先补全输入。缺少必需参数时，任务会明确失败并告诉你缺什么。",
  "dashboard.search.title": "全局知识搜索",
  "dashboard.search.placeholder": "搜索策略、模板、规则…",
  "dashboard.search.empty": "输入关键词开始搜索",
  "dashboard.search.noResults": "没有找到结果",
  "dashboard.source": "技能树来源：{source}",
  "dashboard.enterTree": "展开神经技能树",
  "dashboard.controlPanel": "控制中枢",
  "tree.back": "返回大厅",
  "tree.title": "神经技能树",
  "drawer.tab.overview": "概览",
  "drawer.tab.knowledge": "知识搜索",
  "drawer.section.context": "上下文",
  "drawer.section.modules": "最低技能模块",
  "drawer.section.capabilities": "能力说明",
  "drawer.section.inputs": "输入参数",
  "drawer.section.knowledge": "知识库",
  "drawer.section.coverage": "SOP 覆盖",
  "drawer.section.moduleCapabilities": "模块能力",
  "drawer.context.preconditions": "前置条件",
  "drawer.context.source": "来源",
  "drawer.modules.empty": "当前层级还没有显式技能依赖。",
  "drawer.domain.note": "一级与二级节点仅用于说明与依赖聚合，不直接执行。",
  "drawer.execute.sop": "执行 SOP",
  "drawer.execute.queueing": "正在入队 SOP…",
  "drawer.execute.workflow": "执行工作流",
  "drawer.execute.queueingWorkflow": "正在入队工作流…",
  "drawer.search.placeholder": "搜索知识库…",
  "drawer.search.noResults": "没有找到 “{query}” 的结果",
  "drawer.module.installed": "已安装",
  "drawer.module.required": "缺少",
  "drawer.module.source.skill": "已安装技能",
  "drawer.module.source.foundation": "基础模块",
  "drawer.module.source.integration": "外部集成",
  "drawer.module.source.sop": "工作流资产",
  "drawer.module.install": "安装 / 设置",
  "drawer.module.openLink": "打开下载 / 文档链接",
  "drawer.input.placeholder.generic": "请输入 {label}…",
  "drawer.input.placeholder.url": "请输入链接…",
  "drawer.feedback.queued": "已加入队列：{label}",
  "drawer.feedback.failed.workflow": "工作流入队失败：{command}",
  "drawer.feedback.failed.node": "节点入队失败：{command}",
  "node.level1": "功能大类",
  "node.level2": "具体领域",
  "node.level3": "SOP",
  "toast.learned": "OpenClaw 学到了新策略：{title}",
  "toast.completed": "{label} 已完成。",
  "toast.failed": "{label} 执行失败。",
};

const en: Dictionary = {
  "header.status.linked": "AGENT LINKED",
  "header.status.waiting": "WAITING FOR AGENT",
  "header.theme.toggle": "Toggle Theme",
  "header.lang.toggle": "Toggle Language",
  "skip.main": "Skip to main content",
  "dashboard.hero.title": "Spatial OS",
  "dashboard.hero.subtitle": "OpenClaw Digital Workspace",
  "dashboard.tasks.title": "Global Tasks",
  "dashboard.tasks.live": "{count} Live",
  "dashboard.tasks.agent.online": "Resident Agent Online",
  "dashboard.tasks.agent.waiting": "Waiting for Resident Agent",
  "dashboard.tasks.running": "Running",
  "dashboard.tasks.queued": "Queued",
  "dashboard.tasks.recent": "Recent",
  "dashboard.tasks.empty.running": "No workflows are running. Launch a SOP from the skill drawer to test the app.",
  "dashboard.tasks.empty.queue": "The queue is empty.",
  "dashboard.tasks.empty.recent": "Recent results will appear here.",
  "dashboard.guide.title": "Control Guide",
  "dashboard.guide.line1": "Click a node body to open the side drawer, and use the Chevron to expand the next level.",
  "dashboard.guide.line2": "Each layer shows its minimum skill modules; click a module card to view install steps and details.",
  "dashboard.guide.line3": "Fill the required inputs before running a SOP. Missing parameters fail loudly instead of silently.",
  "dashboard.search.title": "Global Knowledge Search",
  "dashboard.search.placeholder": "Search strategies, templates, rules…",
  "dashboard.search.empty": "Enter a query to search",
  "dashboard.search.noResults": "No results",
  "dashboard.source": "Skill Tree Source: {source}",
  "dashboard.enterTree": "Open Neural Skill Tree",
  "dashboard.controlPanel": "Control Center",
  "tree.back": "Back to Lobby",
  "tree.title": "Neural Skill Tree",
  "drawer.tab.overview": "Overview",
  "drawer.tab.knowledge": "Knowledge Search",
  "drawer.section.context": "Context",
  "drawer.section.modules": "Minimum Skill Modules",
  "drawer.section.capabilities": "Capabilities",
  "drawer.section.inputs": "Inputs",
  "drawer.section.knowledge": "Knowledge Base",
  "drawer.section.coverage": "SOP Coverage",
  "drawer.section.moduleCapabilities": "Module Capabilities",
  "drawer.context.preconditions": "Preconditions",
  "drawer.context.source": "Source",
  "drawer.modules.empty": "No explicit skill dependencies are attached to this layer yet.",
  "drawer.domain.note": "Domain and area nodes aggregate context and dependencies. They do not execute directly.",
  "drawer.execute.sop": "Execute SOP",
  "drawer.execute.queueing": "Queueing SOP…",
  "drawer.execute.workflow": "Run Workflow",
  "drawer.execute.queueingWorkflow": "Queueing Workflow…",
  "drawer.search.placeholder": "Search knowledge base…",
  "drawer.search.noResults": "No results for “{query}”",
  "drawer.module.installed": "INSTALLED",
  "drawer.module.required": "REQUIRED",
  "drawer.module.source.skill": "Installed Skill",
  "drawer.module.source.foundation": "Foundation Module",
  "drawer.module.source.integration": "External Integration",
  "drawer.module.source.sop": "Workflow Asset",
  "drawer.module.install": "Install / Setup",
  "drawer.module.openLink": "Open Download / Documentation",
  "drawer.input.placeholder.generic": "Enter {label}…",
  "drawer.input.placeholder.url": "Paste a URL…",
  "drawer.feedback.queued": "Queued for agent: {label}",
  "drawer.feedback.failed.workflow": "Failed to queue workflow: {command}",
  "drawer.feedback.failed.node": "Failed to queue node: {command}",
  "node.level1": "Function Domain",
  "node.level2": "Specific Area",
  "node.level3": "SOP",
  "toast.learned": "OpenClaw learned a new strategy: {title}",
  "toast.completed": "{label} completed.",
  "toast.failed": "{label} failed.",
};

const dictionaries: Record<Language, Dictionary> = { zh, en };

type I18nContextValue = {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
};

const I18nContext = createContext<I18nContextValue | null>(null);

function detectInitialLanguage(): Language {
  if (typeof window === "undefined") {
    return "zh";
  }

  const stored = window.localStorage.getItem(LANGUAGE_STORAGE_KEY);
  if (stored === "zh" || stored === "en") {
    return stored;
  }

  const languages = window.navigator.languages ?? [window.navigator.language];
  return languages.some((item) => item.toLowerCase().startsWith("zh")) ? "zh" : "en";
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => detectInitialLanguage());

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
    }
    document.documentElement.lang = language === "zh" ? "zh-CN" : "en";
  }, [language]);

  const value = useMemo<I18nContextValue>(
    () => ({
      language,
      setLanguage: setLanguageState,
      t: (key, vars) => {
        let text = dictionaries[language][key] ?? dictionaries.zh[key] ?? key;
        if (!vars) {
          return text;
        }
        for (const [name, value] of Object.entries(vars)) {
          text = text.replaceAll(`{${name}}`, String(value));
        }
        return text;
      },
    }),
    [language],
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18n must be used within I18nProvider");
  }
  return context;
}
