export type NodeStatus = "idle" | "running" | "error";

export interface SkillModule {
  id: string;
  label: string;
  summary: string;
  installed: boolean;
  installCommand?: string;
  installUrl?: string;
  sourcePath?: string;
  sourceType: "skill" | "foundation" | "integration" | "sop";
  capabilities?: string[];
  evidence?: "declared" | "runtime" | "explicit-text";
}

export interface SkillNode {
  id: string;
  level: 1 | 2 | 3;
  label: string;
  status: NodeStatus;
  parentId: string | null;
  sourceType?: "content-system" | "skill" | "sop" | "mock";
  sourcePath?: string;
  subtitle?: string;
  childCount?: number;
  drawerContent?: {
    summary?: string;
    prerequisites?: string;
    minimumSkillsNote?: string;
    capabilities: string[];
    useCases: { title: string; summary: string }[];
    inputs: {
      field: string;
      type: "text" | "slider";
      placeholder?: string;
      required?: boolean;
    }[];
    invoke?: string;
    commands?: string[];
    requiredSkills?: SkillModule[];
    knowledgeBase?: {
      tags: string[];
      documents: { title: string; url: string }[];
    };
  };
}

export interface KnowledgeItem {
  id: string;
  human: {
    title: string;
    summary: string;
    content_md: string;
    tags: string[];
    domain: string;
    platform: string;
    links?: { title: string; url: string }[];
    examples?: { title: string; summary: string; url?: string }[];
  };
  machine: {
    intent: string;
    entities: Record<string, unknown>;
    steps: string[];
    commands: string[];
    constraints: string[];
    trigger?: { type: "cron" | "event"; schedule?: string };
  };
}

export type AgentTaskStatus =
  | "queued"
  | "claimed"
  | "running"
  | "completed"
  | "failed";

export interface AgentTask {
  id: string;
  nodeId: string;
  nodeLabel: string;
  command: string;
  status: AgentTaskStatus;
  createdAt: number;
  updatedAt: number;
  agentId: string | null;
  resultSummary?: string;
  resultDetail?: string;
  context?: {
    sourcePath?: string;
    sourceType?: SkillNode["sourceType"];
    inputValues?: Record<string, string>;
    requiredSkills?: SkillModule[];
  };
}

export interface AgentStatus {
  id: string | null;
  online: boolean;
  lastSeenAt: number | null;
}

export interface PortableBundleExport {
  nodeId: string;
  nodeLabel: string;
  capabilityId: string;
  bundleDir: string;
  zipPath: string;
  relativeZipPath: string;
  downloadUrl: string;
  dependencies: string[];
  packagedCapabilities: string[];
}

export interface HeartbeatPayload {
  status: "alive" | "waiting-for-agent";
  timestamp: number;
  agent: AgentStatus;
  activeTasks: AgentTask[];
  queuedTasks: AgentTask[];
  recentTasks: AgentTask[];
}

export interface SkillTreeResponse {
  nodes: SkillNode[];
  source: string;
}
