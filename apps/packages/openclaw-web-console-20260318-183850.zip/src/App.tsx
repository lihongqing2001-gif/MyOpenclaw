import React, { useState, useCallback, useEffect } from "react";
import {
  ReactFlow,
  Background,
  BackgroundVariant,
  useNodesState,
  useEdgesState,
  Node,
  Edge,
  ReactFlowProvider,
  useReactFlow,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { SkillNodeComponent } from "./components/SkillNodeComponent";
import { GlassDrawer } from "./components/GlassDrawer";
import { DemoModelStage } from "./components/DemoModelStage";
import { mockSkillNodes } from "./data/mockData";
import { generateFlowElements, getLayoutedElements } from "./utils/layout";
import { AgentTask, HeartbeatPayload, KnowledgeItem, SkillNode } from "./types";
import {
  Terminal,
  Sun,
  Moon,
  Activity,
  Search,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import Spline from "@splinetool/react-spline";
import { motion, AnimatePresence } from "motion/react";
import { fetchSkillTree, searchKnowledge, subscribeToKnowledgeStream, subscribeToStream } from "./services/api";
import { Language, useI18n } from "./i18n";

const nodeTypes = {
  skillNode: SkillNodeComponent,
};

type FlowNode = Node<Record<string, unknown> & SkillNode & { isExpanded?: boolean }>;

const recalculateTreeVisibility = (nodes: FlowNode[], edges: Edge[]) => {
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));
  const nextNodes = nodes.map((node) => {
    const data = node.data as SkillNode & { isExpanded?: boolean };
    let hidden = false;

    if (data.level === 2 && data.parentId) {
      const parent = nodeMap.get(data.parentId);
      hidden = !(parent?.data as { isExpanded?: boolean } | undefined)?.isExpanded;
    }

    if (data.level === 3 && data.parentId) {
      const areaNode = nodeMap.get(data.parentId);
      const areaVisible = !areaNode?.hidden;
      const areaExpanded = (areaNode?.data as { isExpanded?: boolean } | undefined)?.isExpanded;
      hidden = !areaVisible || !areaExpanded;
    }

    return {
      ...node,
      hidden,
    };
  });

  const hiddenById = new Map(nextNodes.map((node) => [node.id, node.hidden]));
  const nextNodesWithLeaves = nextNodes.map((node) => {
    const data = node.data as SkillNode & { isExpanded?: boolean };
    if (data.level !== 3 || !data.parentId) {
      return node;
    }

    const areaNode = nextNodes.find((candidate) => candidate.id === data.parentId);
    const areaVisible = !hiddenById.get(data.parentId);
    const areaExpanded = (areaNode?.data as { isExpanded?: boolean } | undefined)?.isExpanded;

    return {
      ...node,
      hidden: !areaVisible || !areaExpanded,
    };
  });

  const finalHiddenById = new Map(
    nextNodesWithLeaves.map((node) => [node.id, node.hidden]),
  );
  const nextEdges = edges.map((edge) => ({
    ...edge,
    hidden: Boolean(
      finalHiddenById.get(edge.source) || finalHiddenById.get(edge.target),
    ),
  }));

  return getLayoutedElements(nextNodesWithLeaves, nextEdges);
};

const collectDescendants = (
  nodeId: string,
  childrenByParent: Map<string | null, SkillNode[]>,
  includeIds: Set<string>,
) => {
  const children = childrenByParent.get(nodeId) ?? [];
  children.forEach((child) => {
    if (!includeIds.has(child.id)) {
      includeIds.add(child.id);
      collectDescendants(child.id, childrenByParent, includeIds);
    }
  });
};

const filterSkillTreeNodes = (skillNodes: SkillNode[], query: string) => {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) {
    return skillNodes;
  }

  const nodeById = new Map(skillNodes.map((node) => [node.id, node]));
  const childrenByParent = new Map<string | null, SkillNode[]>();
  skillNodes.forEach((node) => {
    const bucket = childrenByParent.get(node.parentId ?? null) ?? [];
    bucket.push(node);
    childrenByParent.set(node.parentId ?? null, bucket);
  });

  const includeIds = new Set<string>();

  skillNodes.forEach((node) => {
    const searchableText = [
      node.label,
      node.subtitle,
      node.drawerContent?.summary,
      node.drawerContent?.prerequisites,
      ...(node.drawerContent?.requiredSkills?.map((skill) => skill.label) ?? []),
      ...(node.drawerContent?.knowledgeBase?.tags ?? []),
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    if (!searchableText.includes(normalizedQuery)) {
      return;
    }

    includeIds.add(node.id);

    let parentId = node.parentId;
    while (parentId) {
      includeIds.add(parentId);
      parentId = nodeById.get(parentId)?.parentId ?? null;
    }

    if (node.level !== 3) {
      collectDescendants(node.id, childrenByParent, includeIds);
    }
  });

  return skillNodes.filter((node) => includeIds.has(node.id));
};

const materializeFlowNodes = (
  skillNodes: SkillNode[],
  options?: { expandAllAreas?: boolean; query?: string },
) => {
  const filtered = filterSkillTreeNodes(skillNodes, options?.query ?? "");
  const { nodes: initialNodes, edges } = generateFlowElements(filtered);
  const nextNodes = initialNodes.map((node) => {
    const data = node.data as unknown as SkillNode & { isExpanded?: boolean };
    const expandAllAreas = Boolean(options?.expandAllAreas);
    const hasQuery = Boolean(options?.query?.trim());

    return {
      ...node,
      data: {
        ...node.data,
        isExpanded:
          data.level === 1 ||
          (data.level === 2 ? expandAllAreas || hasQuery : data.isExpanded),
      },
    };
  }) as FlowNode[];

  return recalculateTreeVisibility(nextNodes, edges);
};

const formatTaskTime = (timestamp: number) => {
  const deltaSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (deltaSeconds < 5) {
    return "just now";
  }
  if (deltaSeconds < 60) {
    return `${deltaSeconds}s ago`;
  }
  const deltaMinutes = Math.floor(deltaSeconds / 60);
  if (deltaMinutes < 60) {
    return `${deltaMinutes}m ago`;
  }
  return `${Math.floor(deltaMinutes / 60)}h ago`;
};

const TaskRow = ({
  task,
  tone,
}: {
  task: AgentTask;
  tone: "running" | "queued" | "recent";
}) => (
  <div
    className="px-3 py-2 rounded-lg flex items-center justify-between border gap-3"
    style={{
      backgroundColor: "var(--bg-primary)",
      borderColor: "var(--border-color)",
    }}
  >
    <div className="flex items-center gap-2 min-w-0">
      <span
        className={`w-1.5 h-1.5 rounded-full ${tone === "running" ? "animate-pulse" : ""}`}
        style={{
          backgroundColor:
            tone === "running"
              ? "var(--node-run-text)"
              : tone === "queued"
                ? "var(--text-secondary)"
                : task.status === "failed"
                  ? "var(--node-err-text)"
                  : "var(--text-secondary)",
        }}
      />
      <div className="min-w-0">
        <div
          className="text-xs font-medium truncate"
          style={{ color: "var(--text-primary)" }}
        >
          {task.nodeLabel}
        </div>
        <div
          className="text-[10px] truncate mt-0.5"
          style={{ color: "var(--text-secondary)" }}
        >
          {task.command}
        </div>
        {task.resultSummary && tone === "recent" && (
          <div
            className="text-[10px] truncate mt-1"
            style={{ color: "var(--text-secondary)" }}
          >
            {task.resultSummary}
          </div>
        )}
      </div>
    </div>
    <span
      className="text-[10px] font-mono shrink-0"
      style={{ color: "var(--text-secondary)" }}
    >
      {tone === "queued" ? "queued" : formatTaskTime(task.updatedAt)}
    </span>
  </div>
);

const EmptyTaskState = ({ label }: { label: string }) => (
  <div
    className="px-3 py-3 rounded-lg border text-[11px]"
    style={{
      backgroundColor: "var(--bg-primary)",
      borderColor: "var(--border-color)",
      color: "var(--text-secondary)",
    }}
  >
    {label}
  </div>
);

const QuickGuideModal = ({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) => {
  const { t } = useI18n();

  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-[70]">
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <div className="absolute right-6 top-20 w-[min(28rem,calc(100vw-2rem))] rounded-[1.5rem] border shadow-2xl backdrop-blur-xl"
        style={{
          backgroundColor: "var(--bg-secondary)",
          borderColor: "var(--border-color)",
        }}
      >
        <div
          className="px-5 py-4 border-b flex items-center justify-between"
          style={{ borderColor: "var(--border-color)" }}
        >
          <div
            className="text-sm font-semibold"
            style={{ color: "var(--text-primary)" }}
          >
            {t("dashboard.guide.title")}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full border px-3 py-1 text-[11px]"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-primary)",
            }}
          >
            Close
          </button>
        </div>
        <div className="p-5 space-y-3">
          {[1, 2, 3].map((index) => (
            <div
              key={index}
              className="rounded-xl border px-4 py-4 text-[12px] leading-relaxed"
              style={{
                backgroundColor: "var(--bg-primary)",
                borderColor: "var(--border-color)",
                color: "var(--text-secondary)",
              }}
            >
              {t(`dashboard.guide.line${index}`)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const DashboardHeroCard = ({
  heartbeat,
  onOpenTree,
  onOpenGuide,
}: {
  heartbeat: HeartbeatPayload | null;
  onOpenTree: () => void;
  onOpenGuide: () => void;
}) => {
  const { t } = useI18n();

  return (
    <div
      className="w-full rounded-[1.5rem] border px-5 py-4 shadow-sm"
      style={{
        background: "var(--bg-hero)",
        borderColor: "var(--border-color)",
      }}
    >
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <div
            className="inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[10px] uppercase tracking-[0.22em]"
            style={{
              backgroundColor: "rgba(255,255,255,0.03)",
              borderColor: heartbeat?.agent.online
                ? "var(--node-run-border)"
                : "var(--node-err-border)",
              color: heartbeat?.agent.online
                ? "var(--node-run-text)"
                : "var(--node-err-text)",
            }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{
                backgroundColor: heartbeat?.agent.online
                  ? "var(--node-run-edge)"
                  : "var(--node-err-text)",
              }}
            />
            {heartbeat?.agent.online
              ? t("header.status.linked")
              : t("header.status.waiting")}
          </div>
          <div>
            <h2
              className="text-[1.75rem] md:text-[1.9rem] font-semibold tracking-tight"
              style={{ color: "var(--text-primary)" }}
            >
              OpenClaw Console
            </h2>
          </div>
        </div>

        <div className="flex flex-col gap-3 md:w-[24rem]">
          <button
            type="button"
            onClick={onOpenTree}
            className="rounded-[1.65rem] border px-5 py-6 text-left transition-all hover:-translate-y-0.5 hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-[var(--node-run-edge)]"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
            }}
          >
            <div
              className="text-[10px] uppercase tracking-[0.2em]"
              style={{ color: "var(--text-secondary)" }}
            >
              Primary Action
            </div>
            <div
              className="mt-2 text-base font-semibold"
              style={{ color: "var(--text-primary)" }}
            >
              {t("dashboard.enterTree")}
            </div>
          </button>

          <button
            type="button"
            onClick={onOpenGuide}
            className="rounded-2xl border px-4 py-4 text-left transition-all hover:-translate-y-0.5 hover:shadow-sm"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
            }}
          >
            <div
              className="text-[10px] uppercase tracking-[0.2em]"
              style={{ color: "var(--text-secondary)" }}
            >
              Help
            </div>
            <div
              className="mt-2 text-sm font-semibold"
              style={{ color: "var(--text-primary)" }}
            >
              {t("dashboard.guide.title")}
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

const SkillTreeToolbar = ({
  query,
  onQueryChange,
  onExpandAll,
  onCollapseAll,
  resultCount,
}: {
  query: string;
  onQueryChange: (value: string) => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  resultCount: number;
}) => {
  return (
    <div
      className="absolute top-6 left-1/2 z-20 w-[min(44rem,calc(100%-8rem))] -translate-x-1/2 rounded-[1.35rem] border px-4 py-3 backdrop-blur-xl"
      style={{
        background: "var(--bg-floating)",
        borderColor: "var(--border-color)",
      }}
    >
      <div className="flex flex-col gap-3 md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: "var(--text-secondary)" }}
          />
          <input
            aria-label="Search skill tree"
            type="search"
            value={query}
            onChange={(event) => onQueryChange(event.target.value)}
            placeholder="Search domains, areas, SOPs, skills…"
            className="w-full rounded-xl border pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--node-run-edge)]"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-primary)",
            }}
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onExpandAll}
            className="rounded-xl border px-3 py-2 text-[11px] font-medium"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-primary)",
            }}
          >
            Expand All
          </button>
          <button
            type="button"
            onClick={onCollapseAll}
            className="rounded-xl border px-3 py-2 text-[11px] font-medium"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-primary)",
            }}
          >
            Collapse Areas
          </button>
          <div
            className="rounded-xl border px-3 py-2 text-[11px] font-medium"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-secondary)",
            }}
          >
            {resultCount} nodes
          </div>
        </div>
      </div>
    </div>
  );
};

const GlobalTaskPanel = ({ heartbeat }: { heartbeat: HeartbeatPayload | null }) => {
  const { t } = useI18n();
  const activeTasks = heartbeat?.activeTasks ?? [];
  const queuedTasks = heartbeat?.queuedTasks ?? [];
  const recentTasks = heartbeat?.recentTasks ?? [];

  return (
    <div
      className="w-full rounded-xl border shadow-sm overflow-hidden"
      style={{
        backgroundColor: "var(--bg-secondary)",
        borderColor: "var(--border-color)",
      }}
    >
      <div
        className="px-4 py-3 border-b flex items-center justify-between"
        style={{ borderColor: "var(--border-color)" }}
      >
        <div className="flex items-center gap-2">
          <Activity
            className="w-4 h-4"
            style={{ color: "var(--node-run-text)" }}
          />
          <span
            className="text-xs font-semibold"
            style={{ color: "var(--text-primary)" }}
          >
            {t("dashboard.tasks.title")}
          </span>
        </div>
        <span
          className="text-[10px] font-medium px-2 py-0.5 rounded-full"
          style={{
            backgroundColor: "var(--bg-primary)",
            color: "var(--text-secondary)",
          }}
        >
          {t("dashboard.tasks.live", {
            count: activeTasks.length + queuedTasks.length,
          })}
        </span>
      </div>
      <div className="p-3 space-y-2">
        <div
          className="px-3 py-2 rounded-lg border flex items-center justify-between"
          style={{
            backgroundColor: "var(--bg-primary)",
            borderColor: "var(--border-color)",
          }}
        >
          <div className="flex items-center gap-2">
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{
                backgroundColor: heartbeat?.agent.online
                  ? "var(--node-run-text)"
                  : "var(--node-err-text)",
              }}
            />
            <span
              className="text-xs font-medium"
              style={{ color: "var(--text-primary)" }}
            >
              {heartbeat?.agent.online
                ? t("dashboard.tasks.agent.online")
                : t("dashboard.tasks.agent.waiting")}
            </span>
          </div>
          <span
            className="text-[10px] font-mono"
            style={{ color: "var(--text-secondary)" }}
          >
            {heartbeat?.agent.lastSeenAt
              ? formatTaskTime(heartbeat.agent.lastSeenAt)
              : "offline"}
          </span>
        </div>

        <div
          className="text-[10px] font-semibold uppercase tracking-wider mb-1"
          style={{ color: "var(--text-secondary)" }}
        >
          {t("dashboard.tasks.running")}
        </div>
        {activeTasks.length > 0 ? (
          activeTasks.map((task) => (
            <div key={task.id}>
              <TaskRow task={task} tone="running" />
            </div>
          ))
        ) : (
          <EmptyTaskState label={t("dashboard.tasks.empty.running")} />
        )}

        <div
          className="text-[10px] font-semibold uppercase tracking-wider mt-3 mb-1"
          style={{ color: "var(--text-secondary)" }}
        >
          {t("dashboard.tasks.queued")}
        </div>
        {queuedTasks.length > 0 ? (
          queuedTasks.map((task) => (
            <div key={task.id}>
              <TaskRow task={task} tone="queued" />
            </div>
          ))
        ) : (
          <EmptyTaskState label={t("dashboard.tasks.empty.queue")} />
        )}

        <div
          className="text-[10px] font-semibold uppercase tracking-wider mt-3 mb-1"
          style={{ color: "var(--text-secondary)" }}
        >
          {t("dashboard.tasks.recent")}
        </div>
        {recentTasks.length > 0 ? (
          recentTasks.slice(0, 3).map((task) => (
            <div key={task.id}>
              <TaskRow task={task} tone="recent" />
            </div>
          ))
        ) : (
          <EmptyTaskState label={t("dashboard.tasks.empty.recent")} />
        )}
      </div>
    </div>
  );
};

const GlobalKnowledgeSearch = () => {
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<KnowledgeItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setIsSearching(true);
    try {
      const { results } = await searchKnowledge(query);
      setResults(results);
    } catch (error) {
      console.error(error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div
      className="w-full rounded-xl border shadow-sm overflow-hidden flex flex-col"
      style={{
        backgroundColor: "var(--bg-secondary)",
        borderColor: "var(--border-color)",
      }}
    >
      <div
        className="px-4 py-3 border-b"
        style={{ borderColor: "var(--border-color)" }}
      >
        <span
          className="text-xs font-semibold"
          style={{ color: "var(--text-primary)" }}
        >
          {t("dashboard.search.title")}
        </span>
      </div>
      <div className="p-3 flex-1 flex flex-col">
        <form onSubmit={handleSearch} className="relative mb-3">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: "var(--text-secondary)" }}
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("dashboard.search.placeholder")}
            className="w-full border rounded-md pl-9 pr-3 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all shadow-sm"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
              color: "var(--text-primary)",
            }}
          />
        </form>
        <div className="flex-1 overflow-y-auto space-y-2">
          {isSearching ? (
            <div className="flex justify-center py-4">
              <Loader2
                className="w-4 h-4 animate-spin"
                style={{ color: "var(--text-secondary)" }}
              />
            </div>
          ) : results.length > 0 ? (
            results.map((res) => (
              <a
                key={res.id}
                href={res.human.links?.[0]?.url ?? "#"}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-3 rounded-md border transition-all hover:-translate-y-0.5 hover:shadow-sm"
                style={{
                  backgroundColor: "var(--bg-primary)",
                  borderColor: "var(--border-color)",
                }}
              >
                <div
                  className="text-xs font-medium"
                  style={{ color: "var(--text-primary)" }}
                >
                  {res.human.title}
                </div>
                <div
                  className="text-[10px] mt-1 line-clamp-1"
                  style={{ color: "var(--text-secondary)" }}
                >
                  {res.human.summary}
                </div>
                {res.human.links?.[0] && (
                  <div
                    className="text-[10px] mt-2 truncate"
                    style={{ color: "var(--node-run-edge)" }}
                  >
                    {res.human.links[0].title}
                  </div>
                )}
              </a>
            ))
          ) : query && !isSearching ? (
            <div
              className="text-center py-4 text-xs"
              style={{ color: "var(--text-secondary)" }}
            >
              {t("dashboard.search.noResults")}
            </div>
          ) : (
            <div
              className="text-center py-4 text-xs"
              style={{ color: "var(--text-secondary)" }}
            >
              {t("dashboard.search.empty")}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Flow = () => {
  const { language, setLanguage, t } = useI18n();
  const [nodes, setNodes, onNodesChange] = useNodesState<FlowNode>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<SkillNode | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isLightMode, setIsLightMode] = useState(false);
  const [currentView, setCurrentView] = useState<"dashboard" | "skillTree">(
    "dashboard",
  );
  const [toasts, setToasts] = useState<{ id: string; message: string }[]>([]);
  const [heartbeat, setHeartbeat] = useState<HeartbeatPayload | null>(null);
  const [skillTreeSource, setSkillTreeSource] = useState<string>("loading");
  const [allSkillTreeNodes, setAllSkillTreeNodes] = useState<SkillNode[]>([]);
  const [skillTreeQuery, setSkillTreeQuery] = useState("");
  const [expandAllAreas, setExpandAllAreas] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  const { fitView, setCenter } = useReactFlow();

  useEffect(() => {
    if (isLightMode) {
      document.documentElement.classList.add("light-mode");
    } else {
      document.documentElement.classList.remove("light-mode");
    }
  }, [isLightMode]);

  const toggleTheme = () => setIsLightMode(!isLightMode);

  useEffect(() => {
    let cancelled = false;

    fetchSkillTree().then(({ nodes: skillTreeNodes, source }) => {
      if (cancelled) {
        return;
      }
      setSkillTreeSource(source);
      setAllSkillTreeNodes(skillTreeNodes.length > 0 ? skillTreeNodes : mockSkillNodes);
    });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const skillTreeNodes =
      allSkillTreeNodes.length > 0 ? allSkillTreeNodes : mockSkillNodes;
    const { nodes: layoutedNodes, edges: layoutedEdges } = materializeFlowNodes(
      skillTreeNodes,
      {
        expandAllAreas,
        query: skillTreeQuery,
      },
    );
    setNodes(layoutedNodes as FlowNode[]);
    setEdges(layoutedEdges);
    if (currentView === "skillTree") {
      requestAnimationFrame(() => {
        fitView({ padding: 0.22, duration: 0 });
      });
    }
  }, [
    allSkillTreeNodes,
    skillTreeQuery,
    expandAllAreas,
    currentView,
    fitView,
    setEdges,
    setNodes,
  ]);

  useEffect(() => {
    if (currentView !== "skillTree" || nodes.length === 0 || isDrawerOpen) {
      return;
    }

    const frame = requestAnimationFrame(() => {
      fitView({ padding: 0.22, duration: 0 });
    });

    return () => cancelAnimationFrame(frame);
  }, [currentView, nodes.length, isDrawerOpen, fitView]);

  // SSE Listener for OpenClaw Backend Updates
  useEffect(() => {
    const unsubscribe = subscribeToStream((data) => {
      if (typeof data !== "object" || data === null) {
        return;
      }

      const streamData = data as {
        type?: string;
        payload?: HeartbeatPayload | KnowledgeItem | AgentTask;
        nodeId?: string;
        status?: SkillNode["status"];
        drawerContent?: SkillNode["drawerContent"];
        resultSummary?: string;
      };

      if (streamData.type === "heartbeat" && streamData.payload) {
        setHeartbeat(streamData.payload as HeartbeatPayload);
        return;
      }

      if (streamData.type === "task-updated" && streamData.payload) {
        const task = streamData.payload as unknown as AgentTask;
        if (task.status === "completed" || task.status === "failed") {
          const toastId = `${task.id}-${task.status}`;
          setToasts((prev) => [
            ...prev,
            {
              id: toastId,
              message:
                task.resultSummary ||
                `${task.nodeLabel} ${task.status === "completed" ? "completed" : "failed"}.`,
            },
          ]);
          setTimeout(() => {
            setToasts((prev) => prev.filter((t) => t.id !== toastId));
          }, 4200);
        }
        return;
      }

      // Handle node updates
      if (
        streamData.type === "node-update" ||
        (streamData.nodeId && streamData.status && !streamData.type)
      ) {
        const { nodeId, status, drawerContent } = streamData;

        if (!nodeId || !status) {
          return;
        }

        setNodes((nds) =>
          nds.map((node) => {
            if (node.id === nodeId) {
              const updatedData = { ...node.data, status };
              if (drawerContent) {
                updatedData.drawerContent = drawerContent;
              }
              // If this node is currently selected, update the drawer state too
              if (selectedNode?.id === nodeId) {
                setSelectedNode(updatedData as unknown as SkillNode);
              }
              return { ...node, data: updatedData };
            }
            return node;
          }),
        );

        setEdges((eds) =>
          eds.map((edge) => {
            if (edge.target === nodeId) {
              return {
                ...edge,
                style: {
                  stroke:
                    status === "running"
                      ? "var(--node-run-edge)"
                      : "var(--edge-idle)",
                  strokeWidth: status === "running" ? 2 : 1,
                  strokeDasharray: status === "running" ? "5, 5" : "none",
                  animation:
                    status === "running" ? "flow 0.5s linear infinite" : "none",
                },
              };
            }
            return edge;
          }),
        );
      }
    });

    return unsubscribe;
  }, [setNodes, setEdges, selectedNode]);

  // Knowledge Stream Listener
  useEffect(() => {
    const unsubscribe = subscribeToKnowledgeStream((data) => {
      if (data.type === "upsert") {
        const item = data.payload as KnowledgeItem;
        const toastId = Date.now().toString();
        setToasts((prev) => [
          ...prev,
          {
            id: toastId,
            message: `OpenClaw learned a new strategy: ${item.human.title}`,
          },
        ]);

        // Remove toast after 3 seconds
        setTimeout(() => {
          setToasts((prev) => prev.filter((t) => t.id !== toastId));
        }, 3000);
      }
    });
    return unsubscribe;
  }, []);

  const onNodeClick = useCallback(
    (event: React.MouseEvent, clickedNode: Node) => {
      const target = event.target as HTMLElement | null;
      const shouldToggle = Boolean(
        target?.closest('[data-expand-toggle="true"]'),
      );
      const skillNode = clickedNode.data as unknown as SkillNode & { isExpanded?: boolean };

      if (shouldToggle && (skillNode.level === 1 || skillNode.level === 2)) {
        const nextNodes = nodes.map((node) =>
          node.id === clickedNode.id
            ? {
                ...node,
                data: {
                  ...node.data,
                  isExpanded: !(node.data as { isExpanded?: boolean }).isExpanded,
                },
              }
            : node,
        ) as FlowNode[];

        const { nodes: layoutedNodes, edges: layoutedEdges } =
          recalculateTreeVisibility(nextNodes, edges);
        setNodes(layoutedNodes as FlowNode[]);
        setEdges(layoutedEdges);
        return;
      }

      if (skillNode.drawerContent) {
        setSelectedNode(skillNode);
        setIsDrawerOpen(true);

        setCenter(clickedNode.position.x + 180, clickedNode.position.y, {
          zoom: skillNode.level === 3 ? 1.2 : 1.05,
          duration: 800,
        });
      }
    },
    [nodes, edges, setNodes, setEdges, setCenter],
  );

  const closeDrawer = useCallback(() => {
    setIsDrawerOpen(false);
    setSelectedNode(null);
    // Reset camera to fit view when drawer closes
    setTimeout(() => {
      fitView({ padding: 0.2, duration: 800 });
    }, 100);
  }, [fitView]);

  const handleExpandAllAreas = useCallback(() => {
    setExpandAllAreas(true);
  }, []);

  const handleCollapseAllAreas = useCallback(() => {
    setExpandAllAreas(false);
  }, []);

  const handleLanguageToggle = useCallback(() => {
    setLanguage(language === "zh" ? "en" : "zh");
  }, [language, setLanguage]);

  return (
    <div
      className="w-full h-screen bg-transparent overflow-hidden relative font-sans transition-colors duration-300 flex"
      style={{ color: "var(--text-primary)" }}
    >
      <a
        href="#app-main"
        className="absolute left-4 top-4 z-[100] rounded-full px-4 py-2 text-xs font-medium translate-y-[-200%] focus:translate-y-0 transition-transform"
        style={{
          backgroundColor: "var(--bg-secondary)",
          color: "var(--text-primary)",
          border: "1px solid var(--border-color)",
        }}
      >
        {t("skip.main")}
      </a>
      {/* Header */}
      <header
        className="absolute top-0 left-0 right-0 h-14 border-b z-10 flex items-center px-6 justify-between transition-colors duration-300"
        style={{
          backgroundColor: "var(--bg-secondary)",
          borderColor: "var(--border-color)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="p-1.5 rounded-md border"
            style={{
              backgroundColor: "var(--bg-primary)",
              borderColor: "var(--border-color)",
            }}
          >
            <Terminal
              className="w-4 h-4"
              style={{ color: "var(--text-primary)" }}
            />
          </div>
          <h1 className="text-sm font-semibold tracking-tight">
            OpenClaw{" "}
            <span
              className="font-mono text-xs ml-2"
              style={{ color: "var(--text-secondary)" }}
            >
              v1.0.0
            </span>
          </h1>
        </div>
        <div className="flex items-center gap-6 text-xs font-medium">
          <span
            className="flex items-center gap-2"
            style={{ color: "var(--text-secondary)" }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{
                backgroundColor: heartbeat?.agent.online
                  ? "var(--node-run-text)"
                  : "var(--node-err-text)",
              }}
            />
            {heartbeat?.agent.online
              ? t("header.status.linked")
              : t("header.status.waiting")}
          </span>
          <button
            onClick={handleLanguageToggle}
            className="px-2.5 py-1.5 rounded-md transition-colors border text-[11px] font-semibold"
            style={{
              color: "var(--text-primary)",
              borderColor: "var(--border-color)",
            }}
            aria-label={t("header.lang.toggle")}
            title={t("header.lang.toggle")}
          >
            {language === "zh" ? "EN" : "中文"}
          </button>
          <button
            onClick={toggleTheme}
            className="p-1.5 rounded-md transition-colors hover:bg-black/5 dark:hover:bg-white/5 border"
            style={{
              color: "var(--text-secondary)",
              borderColor: "var(--border-color)",
            }}
            aria-label={t("header.theme.toggle")}
            title={t("header.theme.toggle")}
          >
            {isLightMode ? (
              <Moon className="w-4 h-4" />
            ) : (
              <Sun className="w-4 h-4" />
            )}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main id="app-main" className="w-full h-full pt-14 relative">
        <AnimatePresence mode="wait">
          {currentView === "dashboard" ? (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="w-full h-full flex flex-col md:flex-row overflow-hidden"
            >
              {/* 3D Hub Overlay (Left Side) */}
              <div
                className="w-full h-64 md:h-full md:w-[45%] border-b md:border-b-0 md:border-r relative z-0 shrink-0"
                style={{
                  borderColor: "var(--border-color)",
                  backgroundColor: "var(--bg-primary)",
                }}
              >
                <Spline scene="https://prod.spline.design/6Wq1Q7YGyM-iab9i/scene.splinecode" />
                <DemoModelStage />
                <div className="absolute top-8 left-6 pointer-events-none">
                  <h2
                    className="text-lg font-semibold tracking-tight"
                    style={{ color: "var(--text-primary)" }}
                  >
                    {t("dashboard.hero.title")}
                  </h2>
                  <p
                    className="text-xs mt-1"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {t("dashboard.hero.subtitle")}
                  </p>
                </div>
              </div>

              {/* Control Center (Right Side) */}
              <div
                className="w-full md:w-[55%] h-full p-4 md:p-8 flex flex-col gap-6 overflow-y-auto"
                style={{ backgroundColor: "var(--bg-primary)" }}
              >
                <div className="max-w-2xl w-full mx-auto space-y-6">
                  <DashboardHeroCard
                    heartbeat={heartbeat}
                    onOpenTree={() => setCurrentView("skillTree")}
                    onOpenGuide={() => setIsGuideOpen(true)}
                  />
                  <GlobalTaskPanel heartbeat={heartbeat} />
                  <div className="h-64">
                    <GlobalKnowledgeSearch />
                  </div>
                  <div
                    className="rounded-xl border px-4 py-3 text-[11px]"
                    style={{
                      backgroundColor: "var(--bg-secondary)",
                      borderColor: "var(--border-color)",
                      color: "var(--text-secondary)",
                    }}
                  >
                    {t("dashboard.source", { source: skillTreeSource })}
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="skillTree"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="w-full h-full relative p-4 md:p-8 lg:p-12"
            >
              {/* Back Button */}
              <div className="absolute top-6 left-6 z-20">
                <button
                  onClick={() => setCurrentView("dashboard")}
                  className="flex items-center gap-2 px-3 py-2 rounded-md border shadow-sm text-xs font-medium transition-colors hover:bg-black/5 dark:hover:bg-white/5 backdrop-blur-md"
                  style={{
                    backgroundColor: "var(--bg-secondary)",
                    borderColor: "var(--border-color)",
                    color: "var(--text-primary)",
                  }}
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {t("tree.back")}
                </button>
              </div>

              <SkillTreeToolbar
                query={skillTreeQuery}
                onQueryChange={setSkillTreeQuery}
                onExpandAll={handleExpandAllAreas}
                onCollapseAll={handleCollapseAllAreas}
                resultCount={nodes.filter((node) => !node.hidden).length}
              />

              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onNodeClick={onNodeClick}
                nodeTypes={nodeTypes}
                className="bg-transparent"
                minZoom={0.1}
                maxZoom={2}
                panOnScroll={true}
                selectionOnDrag={false}
                zoomOnScroll={false}
                zoomOnPinch={true}
                zoomOnDoubleClick={false}
                panOnDrag={true}
                nodesDraggable={false}
                preventScrolling={false}
              >
                <Background
                  variant={BackgroundVariant.Dots}
                  gap={24}
                  size={1}
                  color="rgba(150,150,150,0.2)"
                />
              </ReactFlow>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <QuickGuideModal open={isGuideOpen} onClose={() => setIsGuideOpen(false)} />

      {/* Drawer */}
      <GlassDrawer
        isOpen={isDrawerOpen && currentView === "skillTree"}
        onClose={closeDrawer}
        node={selectedNode}
      />

      {/* Toasts */}
      <div
        className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none"
        aria-live="polite"
      >
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="px-4 py-3 rounded-lg border shadow-lg backdrop-blur-md max-w-sm"
              style={{
                backgroundColor: "var(--bg-secondary)",
                borderColor: "var(--border-color)",
              }}
            >
              <div className="flex items-start gap-3">
                <div
                  className="w-2 h-2 rounded-full mt-1.5 shrink-0 animate-pulse"
                  style={{ backgroundColor: "var(--node-run-text)" }}
                />
                <p
                  className="text-xs font-medium leading-relaxed"
                  style={{ color: "var(--text-primary)" }}
                >
                  {toast.message}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <ReactFlowProvider>
      <Flow />
    </ReactFlowProvider>
  );
}
