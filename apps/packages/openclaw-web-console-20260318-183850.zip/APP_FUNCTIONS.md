# OpenClaw Web 控制台功能总览

这是一份给人类阅读的说明书，用来快速理解当前 OpenClaw Web 控制台能做什么、怎么用、哪些地方是真执行、哪些地方依赖额外条件。

## 1. 这个 App 是什么

OpenClaw Web 控制台是一个面向 OpenClaw Agent 的可视化操作台。

它不是单纯的静态展示页，而是由三部分共同组成：

- Web 前端：负责展示技能树、知识库、任务状态、3D 角色与交互界面
- Broker 服务：负责转发 UI 请求、维护任务队列、推送 SSE 实时事件
- Resident Agent：负责领取任务并真正执行命令，再把结果回写到 UI

## 2. 大厅页面能做什么

大厅是默认首页，主要提供四类能力。

### 2.1 3D Demo Stage

左侧是预留的 3D demo 区。

当前支持：

- 展示接入的 3D 模型
- 手动拖拽旋转
- 跟随明暗主题变化背景与灯光
- 播放模型自带动画（当模型包含动画时）

### 2.2 Global Tasks

右侧大厅中的任务面板会展示：

- 当前正在运行的任务
- 队列中的任务
- 最近完成或失败的任务
- Resident Agent 是否在线

### 2.3 Global Knowledge Search

你可以直接在大厅搜索知识库。

搜索来源包括：

- 默认种子知识库
- Resident Agent 执行后回写的运行产物
- `agents/knowledge` 中的真实 Markdown 文档
- `qmd` 返回的索引结果

### 2.4 进入技能树

大厅底部按钮可以进入技能树视图。

## 3. 技能树页面能做什么

当前技能树遵循三层结构：

- 第一层：功能大类
- 第二层：具体领域
- 第三层：SOP / Workflow

### 3.1 节点交互规则

- 点击节点主体：打开右侧侧边栏
- 点击节点右侧 Chevron：展开 / 折叠子层级

### 3.2 侧边栏内容

每个层级打开侧边栏后，都会展示：

- 当前层级说明
- 前置条件
- 最低技能模块要求
- 技能模块卡片
- 能力说明
- 输入项
- 知识文档
- SOP 覆盖范围

### 3.3 技能模块卡片

技能模块卡片会告诉你：

- 这个 SOP / 领域 / 大类最少需要哪些技能
- 该技能是否已安装
- 技能的用途是什么

点击技能模块卡片，会弹出详情窗口，显示：

- 技能说明
- 安装命令
- 下载 / 文档链接
- 源文件位置
- 证据来源（`DECLARED` / `RUNTIME` / `EXPLICIT-TEXT`）

## 4. 现在技能树的数据来自哪里

当前技能树优先从真实 OpenClaw workspace 导入，而不是只用 mock 数据。

主要来源：

- `~/.openclaw/workspace/content_system/skilltree/data.json`
- `~/.openclaw/workspace/skills/*/SKILL.md`
- `~/.openclaw/workspace/sops/*.md`

如果这些真实数据源不可用，才会回退到前端 mock。

## 5. 点击 SOP 的“运行”现在会发生什么

这是当前最重要的一部分。

### 5.1 运行路径

点击执行按钮后，流程如下：

1. 前端收集输入框内容
2. 前端把 `nodeId + command + 输入值 + 来源路径 + 技能模块信息` 发给 broker
3. Broker 把它放进任务队列
4. Resident Agent 轮询到任务后开始执行
5. 执行结果通过 SSE 回写到 UI
6. 结果会出现在：
   - 节点状态
   - Recent 任务列表
   - Toast 提示
   - 运行产物知识条目

### 5.2 命令分两类

当前系统支持两类执行。

#### A. Shell / Python / npm / claw 之类的真实命令

例如：

- `python scripts/cli.py ...`
- `npm run ...`
- `claw ...`

这类会由 Resident Agent 在正确工作目录里直接执行。

#### B. Slash 风格 OpenClaw 命令

例如：

- `/content run --style xiaogai --count 1`
- `/growth plan ...`

这类不会直接当 shell 执行，而会转交给 OpenClaw CLI 入口处理。

## 6. 为什么之前点击 SOP 像是“没运行”

之前的原因主要有三个：

### 6.1 Resident Agent 只是演示模式

最开始它只会：

- 把任务标成 running
- 等一下
- 伪造 completed / failed

不会真正执行命令。

### 6.2 输入框没有真正参与执行

之前 Drawer 里的输入只是展示，不会进入实际 payload。

所以很多 SOP 即使需要：

- URL
- token
- 输出路径

点运行时也没有参数，自然无法真正执行。

### 6.3 某些 SOP 本来就带占位符

例如：

- `--feed-id <id>`
- `--xsec-token <token>`

如果用户没填输入，就不能直接运行。

## 7. 现在已经改善了什么

当前版本已经补上了这些能力：

- 输入框内容会随执行一起提交
- Resident Agent 会真正尝试执行命令
- 如果存在未填占位符，会明确失败并提示缺少哪些输入
- 运行完成后会把结果摘要回写到 UI
- Recent 面板会显示结果摘要
- 成功 / 失败会弹出 toast
- 本地知识文档通过 Web 路由可打开
- 全局知识搜索支持 `qmd` 结果
- 运行成功后会写出案例知识并执行 `qmd update`

## 8. 以小红书评论语义提取 SOP 为例

`Xiaohongshu Comment Semantic Extraction (Auto Excel)` 目前会被组织到：

- 功能大类：`内容与社媒运营`
- 具体领域：`小红书评论与数据工作流`
- SOP：`Xiaohongshu Comment Semantic Extraction (Auto Excel)`

它目前至少依赖：

- `xiaohongshu-skills`

如果你要让它真正执行，至少应在 Drawer 填写：

- Xiaohongshu note URL

系统会尝试从 URL 中提取：

- `feed_id`
- `xsec_token`

然后拼成真正可执行命令。

## 9. 目前仍然存在的限制

当前版本已经是“真执行链路”，但仍处于持续完善阶段。

### 9.1 不是所有 SOP 都已经拥有完整执行器

有些 SOP 文档已经能运行，有些仍然只是说明型工作流。

这类节点需要进一步补：

- 参数映射
- 运行目录
- 输出文件约定
- 成功判定条件

### 9.2 Slash 风格命令依赖 OpenClaw 本体状态

如果某个 agent 没有配置好模型 / auth / workspace，上层 slash 命令仍然可能失败。

### 9.3 某些复杂 SOP 只是接通了第一段执行链

像“小红书评论语义提取到 Excel”这种复杂 SOP，往往不仅是抓评论，还包括：

- 语义解析
- 拆分多商品评论
- 生成最终 Excel

如果底层脚本没有完整自动化到最后一步，还需要后续继续补工作流脚本。

## 10. 当前页面中你应该如何使用它

推荐顺序：

1. 先确认大厅显示 `AGENT LINKED`
2. 进入技能树
3. 找到目标 SOP
4. 打开侧边栏
5. 看最低技能模块是否已安装
6. 补全输入项
7. 点击执行
8. 回到大厅观察 Running / Queued / Recent
9. 执行结束后查看结果 toast 和知识回写

## 11. 这个 App 适合什么场景

当前版本最适合：

- OpenClaw 技能与 SOP 可视化管理
- 按功能大类 / 具体领域浏览工作流
- 查看某个 SOP 最少依赖哪些技能模块
- 通过 UI 触发可执行工作流
- 观察 OpenClaw Resident Agent 的执行状态
- 查看运行后自动生成的案例知识与搜索结果

## 12. 后续最值得继续做的三件事

如果继续迭代，这三个方向价值最高：

### 12.1 完整 SOP 执行器

把复杂 SOP 从“命令触发”升级成：

- 参数校验
- 预处理
- 多步骤执行
- 标准输出物生成

### 12.2 更强的输入映射系统

让 SOP 可以声明：

- 哪个输入对应哪个命令参数
- 哪个输入需要自动解析
- 哪些字段是必填

### 12.3 更高级的 3D Spatial OS 体验

包括：

- 更稳的模型适屏与灯光
- 更清晰的 demo 区与业务区分层
- 针对业务状态的环境反馈，而不是装饰性角色层

## 13. 已经跑通的示例

当前已经实测跑通或显式接入的节点包括：

- `日程规划与冲突检测`
- `资料清单化与索引`
- `自动整理归档`

运行成功后会：

- 写入 `agents/knowledge/cases/`
- 执行 `qmd update`
- 在 UI 的全局知识搜索中可见

## 14. 当前推荐打开方式

优先使用：

- `http://127.0.0.1:3000`

建议启动方式：

```bash
python3 start_app.py
```

这会同时启动：

- Broker
- Resident Agent
