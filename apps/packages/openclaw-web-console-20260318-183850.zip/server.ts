import express from "express";
import { spawnSync } from "node:child_process";
import { createServer as createViteServer } from "vite";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { seedKnowledgeBase } from "./src/data/mockKnowledge";
import { mockSkillNodes } from "./src/data/mockData";
import { buildWorkspaceKnowledgeItems } from "./src/server/knowledgeLoader";
import { loadSkillTreeNodes, recordRuntimeSkillEvidence } from "./src/server/skillTreeLoader";
import {
  AgentStatus,
  AgentTask,
  AgentTaskStatus,
  KnowledgeItem,
  NodeStatus,
  SkillModule,
  SkillNode,
} from "./src/types";

type StreamEvent =
  | { type: "connected" }
  | { type: "heartbeat"; payload: ReturnType<typeof buildHeartbeatPayload> }
  | { type: "knowledge"; action: "upsert" | "delete"; payload: KnowledgeItem }
  | {
      type: "node-update";
      nodeId: string;
      status: NodeStatus;
      drawerContent?: unknown;
    }
  | { type: "task-queued" | "task-claimed" | "task-updated"; payload: AgentTask };

type TaskUpdateStatus = Extract<
  AgentTaskStatus,
  "running" | "completed" | "failed"
>;

interface TaskUpdateRequest {
  agentId?: string;
  taskId?: string;
  status?: TaskUpdateStatus;
  nodeStatus?: NodeStatus;
  drawerContent?: unknown;
  resultSummary?: string;
  resultDetail?: string;
  runtimeSkillsUsed?: SkillModule[];
  knowledgeAction?: "upsert" | "delete";
  knowledgePayload?: KnowledgeItem;
}

const HEARTBEAT_INTERVAL_MS = 5000;
const AGENT_OFFLINE_TIMEOUT_MS = 15000;
const TASK_CLAIM_TIMEOUT_MS = 30000;
const MAX_RECENT_TASKS = 8;
const homeDir = os.homedir();
const docRoots = [
  path.join(homeDir, ".openclaw"),
  process.cwd(),
];

const runtimeKnowledgeDb: KnowledgeItem[] = [...seedKnowledgeBase];
const commandQueue: AgentTask[] = [];
let agentState: AgentStatus = {
  id: null,
  online: false,
  lastSeenAt: null,
};

function now() {
  return Date.now();
}

function broadcast(clients: express.Response[], event: StreamEvent) {
  const payload = `data: ${JSON.stringify(event)}\n\n`;
  clients.forEach((client) => client.write(payload));
}

function refreshAgentStatus() {
  if (!agentState.lastSeenAt) {
    agentState = { ...agentState, online: false };
    return;
  }

  agentState = {
    ...agentState,
    online: now() - agentState.lastSeenAt <= AGENT_OFFLINE_TIMEOUT_MS,
  };
}

function recycleStaleClaims() {
  const recycleBefore = now() - TASK_CLAIM_TIMEOUT_MS;
  commandQueue.forEach((task) => {
    if (task.status === "claimed" && task.updatedAt < recycleBefore) {
      task.status = "queued";
      task.updatedAt = now();
      task.agentId = null;
      task.resultSummary = "Task claim timed out and was re-queued.";
    }
  });
}

function buildHeartbeatPayload() {
  refreshAgentStatus();
  recycleStaleClaims();

  const activeTasks = commandQueue.filter(
    (task) => task.status === "claimed" || task.status === "running",
  );
  const queuedTasks = commandQueue.filter((task) => task.status === "queued");
  const recentTasks = [...commandQueue]
    .filter(
      (task) => task.status === "completed" || task.status === "failed",
    )
    .sort((a, b) => b.updatedAt - a.updatedAt)
    .slice(0, MAX_RECENT_TASKS);

  return {
    status: agentState.online ? "alive" : "waiting-for-agent",
    timestamp: now(),
    agent: agentState,
    activeTasks,
    queuedTasks,
    recentTasks,
  };
}

function emitHeartbeat(clients: express.Response[]) {
  broadcast(clients, {
    type: "heartbeat",
    payload: buildHeartbeatPayload(),
  });
}

function upsertKnowledge(item: KnowledgeItem) {
  const index = runtimeKnowledgeDb.findIndex((entry) => entry.id === item.id);
  if (index >= 0) {
    runtimeKnowledgeDb[index] = item;
    return;
  }
  runtimeKnowledgeDb.unshift(item);
}

function deleteKnowledge(id: string) {
  const index = runtimeKnowledgeDb.findIndex((entry) => entry.id === id);
  if (index >= 0) {
    runtimeKnowledgeDb.splice(index, 1);
  }
}

function getKnowledgeDb() {
  const workspaceItems = buildWorkspaceKnowledgeItems();
  const seen = new Set<string>();
  return [...runtimeKnowledgeDb, ...workspaceItems].filter((item) => {
    if (seen.has(item.id)) {
      return false;
    }
    seen.add(item.id);
    return true;
  });
}

function searchKnowledge(
  query?: string,
  domain?: string,
  platform?: string,
): KnowledgeItem[] {
  const normalizedQuery = (query ?? "").trim();
  return getKnowledgeDb().filter((item) => {
    const matchQuery = normalizedQuery
      ? item.human.title.includes(normalizedQuery) ||
        item.human.summary.includes(normalizedQuery) ||
        item.human.content_md.includes(normalizedQuery) ||
        item.human.tags.some((tag) => tag.includes(normalizedQuery)) ||
        (item.human.links ?? []).some(
          (link) =>
            link.title.includes(normalizedQuery) ||
            link.url.includes(normalizedQuery),
        ) ||
        (item.human.examples ?? []).some(
          (example) =>
            example.title.includes(normalizedQuery) ||
            example.summary.includes(normalizedQuery),
        ) ||
        item.machine.steps.some((step) => step.includes(normalizedQuery)) ||
        item.machine.commands.some((command) =>
          command.includes(normalizedQuery),
        )
      : true;
    const matchDomain = domain ? item.human.domain === domain : true;
    const matchPlatform = platform ? item.human.platform === platform : true;
    return matchQuery && matchDomain && matchPlatform;
  });
}

function qmdResultToKnowledgeItem(
  result: {
    docid?: string;
    score?: number;
    file?: string;
    title?: string;
    snippet?: string;
  },
  collection: string,
): KnowledgeItem {
  const ref = result.file ?? "";
  return {
    id: `kb-qmd-${collection}-${(result.docid ?? ref).replace(/[^a-zA-Z0-9]+/g, "-").toLowerCase()}`,
    human: {
      title: result.title || ref || "QMD Result",
      summary: result.snippet || "Indexed by qmd",
      content_md: result.snippet || "",
      tags: ["qmd", collection],
      domain: "QMD",
      platform: collection,
      links: ref
        ? [{ title: result.title || ref, url: `/api/v1/qmd-doc?ref=${encodeURIComponent(ref)}` }]
        : [],
    },
    machine: {
      intent: "qmd_search_result",
      entities: { ref, docid: result.docid, score: result.score },
      steps: [],
      commands: [],
      constraints: [],
    },
  };
}

function searchQmdCollection(query: string, collection: string): KnowledgeItem[] {
  const process = spawnSync(
    "qmd",
    ["search", query, "-c", collection, "--json"],
    {
      encoding: "utf-8",
      timeout: 15000,
    },
  );

  if (process.status !== 0 || !process.stdout.trim()) {
    return [];
  }

  try {
    const items = JSON.parse(process.stdout) as Array<{
      docid?: string;
      score?: number;
      file?: string;
      title?: string;
      snippet?: string;
    }>;
    return items.slice(0, 8).map((item) => qmdResultToKnowledgeItem(item, collection));
  } catch {
    return [];
  }
}

function searchQmdKnowledge(query?: string) {
  const normalizedQuery = (query ?? "").trim();
  if (!normalizedQuery) {
    return [];
  }

  return [
    ...searchQmdCollection(normalizedQuery, "agents-knowledge"),
    ...searchQmdCollection(normalizedQuery, "content-knowledge"),
  ];
}

function createTask(
  nodeId: string,
  command: string,
  context?: AgentTask["context"],
): AgentTask {
  const timestamp = now();
  const skillTreeNodes = getSkillTreeNodes();
  const nodeLabelById = new Map(
    skillTreeNodes.map((node) => [node.id, node.label] as const),
  );
  return {
    id: `task_${timestamp}_${Math.random().toString(36).slice(2, 8)}`,
    nodeId,
    nodeLabel: nodeLabelById.get(nodeId) ?? nodeId,
    command,
    status: "queued",
    createdAt: timestamp,
    updatedAt: timestamp,
    agentId: null,
    context,
  };
}

function getSkillTreeNodes() {
  const loadedNodes = loadSkillTreeNodes();
  return loadedNodes.length > 0 ? loadedNodes : mockSkillNodes;
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function isAllowedDocPath(targetPath: string) {
  const resolved = path.resolve(targetPath);
  return docRoots.some((root) => resolved.startsWith(path.resolve(root)));
}

async function startServer() {
  const app = express();
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());
  app.use("/exports", express.static(path.join(process.cwd(), "exports")));

  let clients: express.Response[] = [];

  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      heartbeat: buildHeartbeatPayload(),
    });
  });

  app.get("/api/v1/stream", (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();

    clients.push(res);

    broadcast([res], { type: "connected" });
    emitHeartbeat([res]);

    req.on("close", () => {
      clients = clients.filter((client) => client !== res);
    });
  });

  setInterval(() => {
    emitHeartbeat(clients);
  }, HEARTBEAT_INTERVAL_MS);

  app.get("/api/v1/stream-vibe", (_req, res) => {
    res.redirect(307, "/api/v1/stream");
  });

  app.get("/api/v1/skill-tree", (_req, res) => {
    res.json({
      nodes: getSkillTreeNodes(),
      source: "openclaw-workspace",
    });
  });

  app.get("/api/v1/doc", (req, res) => {
    const rawPath =
      typeof req.query.path === "string" ? req.query.path.trim() : "";
    if (!rawPath) {
      return res.status(400).send("Missing path");
    }

    if (!isAllowedDocPath(rawPath)) {
      return res.status(403).send("Path not allowed");
    }

    if (!fs.existsSync(rawPath) || !fs.statSync(rawPath).isFile()) {
      return res.status(404).send("Document not found");
    }

    const content = fs.readFileSync(rawPath, "utf-8");
    const title = path.basename(rawPath);
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(`<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${escapeHtml(title)}</title>
    <style>
      body { margin: 0; background: #f6f7fb; color: #12151d; font: 16px/1.65 -apple-system, BlinkMacSystemFont, "SF Pro Text", "PingFang SC", sans-serif; }
      .shell { max-width: 960px; margin: 0 auto; padding: 32px 20px 80px; }
      .meta { margin-bottom: 18px; color: #667085; font-size: 13px; }
      .card { background: white; border: 1px solid #e4e7ec; border-radius: 20px; padding: 28px; box-shadow: 0 18px 48px rgba(16,24,40,0.08); }
      pre { white-space: pre-wrap; word-break: break-word; font: 14px/1.7 "JetBrains Mono", ui-monospace, monospace; margin: 0; }
      a { color: #1463ff; }
    </style>
  </head>
  <body>
    <div class="shell">
      <div class="meta">${escapeHtml(rawPath)}</div>
      <div class="card"><pre>${escapeHtml(content)}</pre></div>
    </div>
  </body>
</html>`);
  });

  app.get("/api/v1/qmd-doc", (req, res) => {
    const ref = typeof req.query.ref === "string" ? req.query.ref.trim() : "";
    if (!ref) {
      return res.status(400).send("Missing ref");
    }

    const process = spawnSync("qmd", ["get", ref], {
      encoding: "utf-8",
      timeout: 15000,
    });

    if (process.status !== 0) {
      return res.status(404).send("QMD document not found");
    }

    const content = process.stdout || process.stderr || "";
    res.setHeader("Content-Type", "text/html; charset=utf-8");
    res.send(`<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${escapeHtml(ref)}</title>
    <style>
      body { margin: 0; background: #f6f7fb; color: #12151d; font: 16px/1.65 -apple-system, BlinkMacSystemFont, "SF Pro Text", "PingFang SC", sans-serif; }
      .shell { max-width: 960px; margin: 0 auto; padding: 32px 20px 80px; }
      .meta { margin-bottom: 18px; color: #667085; font-size: 13px; }
      .card { background: white; border: 1px solid #e4e7ec; border-radius: 20px; padding: 28px; box-shadow: 0 18px 48px rgba(16,24,40,0.08); }
      pre { white-space: pre-wrap; word-break: break-word; font: 14px/1.7 "JetBrains Mono", ui-monospace, monospace; margin: 0; }
    </style>
  </head>
  <body>
    <div class="shell">
      <div class="meta">${escapeHtml(ref)}</div>
      <div class="card"><pre>${escapeHtml(content)}</pre></div>
    </div>
  </body>
</html>`);
  });

  app.post("/api/v1/heartbeat", (req, res) => {
    const nextAgentId =
      typeof req.body?.agentId === "string" && req.body.agentId.trim()
        ? req.body.agentId.trim()
        : agentState.id;

    agentState = {
      id: nextAgentId ?? "openclaw-agent",
      online: true,
      lastSeenAt: now(),
    };

    emitHeartbeat(clients);
    res.json({ success: true });
  });

  app.post("/api/v1/knowledge/ingest", (req, res) => {
    const action = req.body?.action === "delete" ? "delete" : "upsert";
    const payload = req.body?.payload as KnowledgeItem | undefined;

    if (!payload?.id) {
      return res.status(400).json({ error: "Knowledge payload is required" });
    }

    if (action === "delete") {
      deleteKnowledge(payload.id);
    } else {
      upsertKnowledge(payload);
    }

    broadcast(clients, {
      type: "knowledge",
      action,
      payload,
    });

    res.json({ success: true });
  });

  app.post("/api/v1/node-update", (req, res) => {
    const { nodeId, status, drawerContent } = req.body ?? {};

    if (!nodeId || !status) {
      return res
        .status(400)
        .json({ error: "nodeId and status are required" });
    }

    broadcast(clients, {
      type: "node-update",
      nodeId,
      status,
      drawerContent,
    });

    res.json({ success: true, message: `Node ${nodeId} updated to ${status}` });
  });

  app.post("/api/v1/update-vibe", (_req, res) => {
    res.redirect(307, "/api/v1/node-update");
  });

  app.post("/api/v1/node-execute", (req, res) => {
    const {
      nodeId,
      command,
      inputValues,
      sourcePath,
      sourceType,
      requiredSkills,
    } = req.body ?? {};

    if (!nodeId || !command) {
      return res
        .status(400)
        .json({ error: "nodeId and command are required" });
    }

    const task = createTask(nodeId, command, {
      inputValues:
        inputValues && typeof inputValues === "object" ? inputValues : {},
      sourcePath: typeof sourcePath === "string" ? sourcePath : undefined,
      sourceType: sourceType as SkillNode["sourceType"] | undefined,
      requiredSkills: Array.isArray(requiredSkills)
        ? (requiredSkills as SkillModule[])
        : [],
    });
    commandQueue.push(task);

    broadcast(clients, {
      type: "task-queued",
      payload: task,
    });
    emitHeartbeat(clients);

    res.json({
      success: true,
      message: `Execution command queued for ${nodeId}`,
      task,
    });
  });

  app.post("/api/v1/bundles/export", (req, res) => {
    const nodeId =
      typeof req.body?.nodeId === "string" ? req.body.nodeId.trim() : "";
    const exportAll = Boolean(req.body?.all);

    if (!nodeId && !exportAll) {
      return res.status(400).json({ error: "nodeId or all is required" });
    }

    const args = [
      "scripts/export_sop_bundle.py",
      "--output-dir",
      path.join(process.cwd(), "exports", "bundles"),
      "--base-url",
      `http://127.0.0.1:${port}`,
      "--json",
    ];

    if (exportAll) {
      args.push("--all");
    } else {
      args.push("--node-id", nodeId);
    }

    const exportProcess = spawnSync("python3", args, {
      cwd: process.cwd(),
      encoding: "utf-8",
      timeout: 60000,
    });

    if (exportProcess.status !== 0) {
      return res.status(500).json({
        error:
          exportProcess.stderr?.trim() ||
          exportProcess.stdout?.trim() ||
          "Bundle export failed",
      });
    }

    try {
      const payload = JSON.parse(exportProcess.stdout.trim());
      return res.json({ success: true, ...payload });
    } catch {
      return res.status(500).json({ error: "Bundle export returned invalid JSON" });
    }
  });

  app.post("/api/v1/agent/poll", (req, res) => {
    const requestedAgentId =
      typeof req.body?.agentId === "string" && req.body.agentId.trim()
        ? req.body.agentId.trim()
        : "openclaw-agent";

    agentState = {
      id: requestedAgentId,
      online: true,
      lastSeenAt: now(),
    };

    recycleStaleClaims();

    const task = commandQueue.find((item) => item.status === "queued") ?? null;
    if (task) {
      task.status = "claimed";
      task.updatedAt = now();
      task.agentId = requestedAgentId;

      broadcast(clients, {
        type: "task-claimed",
        payload: task,
      });
    }

    emitHeartbeat(clients);
    res.json({ success: true, task });
  });

  app.post("/api/v1/agent/task-update", (req, res) => {
    const payload = (req.body ?? {}) as TaskUpdateRequest;
    if (!payload.taskId || !payload.status) {
      return res
        .status(400)
        .json({ error: "taskId and status are required" });
    }

    const task = commandQueue.find((item) => item.id === payload.taskId);
    if (!task) {
      return res.status(404).json({ error: "Task not found" });
    }

    task.status = payload.status;
    task.updatedAt = now();
    task.agentId = payload.agentId ?? task.agentId;
    task.resultSummary = payload.resultSummary ?? task.resultSummary;
    task.resultDetail = payload.resultDetail ?? task.resultDetail;

    if (Array.isArray(payload.runtimeSkillsUsed) && payload.runtimeSkillsUsed.length > 0) {
      recordRuntimeSkillEvidence(task.nodeId, payload.runtimeSkillsUsed);
    }

    if (payload.nodeStatus) {
      broadcast(clients, {
        type: "node-update",
        nodeId: task.nodeId,
        status: payload.nodeStatus,
        drawerContent: payload.drawerContent,
      });
    }

    if (payload.knowledgePayload) {
      const action = payload.knowledgeAction ?? "upsert";
      if (action === "delete") {
        deleteKnowledge(payload.knowledgePayload.id);
      } else {
        upsertKnowledge(payload.knowledgePayload);
      }

      broadcast(clients, {
        type: "knowledge",
        action,
        payload: payload.knowledgePayload,
      });
    }

    broadcast(clients, {
      type: "task-updated",
      payload: task,
    });
    emitHeartbeat(clients);

    res.json({ success: true, task });
  });

  app.post("/api/v1/knowledge/search", (req, res) => {
    const { query, domain, platform } = req.body ?? {};
    const qmdResults = searchQmdKnowledge(query);
    res.json({
      results: [...searchKnowledge(query, domain, platform), ...qmdResults],
    });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${port}`);
    console.log("OpenClaw broker endpoints ready:");
    console.log("  UI SSE:          GET  /api/v1/stream");
    console.log("  Agent poll:      POST /api/v1/agent/poll");
    console.log("  Agent task sync: POST /api/v1/agent/task-update");
  });
}

startServer();
