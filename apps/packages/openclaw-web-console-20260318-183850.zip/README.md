# OpenClaw Web App

OpenClaw Web is a spatial control console for a resident OpenClaw agent. The frontend is intentionally lightweight: it renders 3D and graph state, while the broker server and the standalone agent own task execution, heartbeats, and knowledge updates.

## What Runs Where

### Web broker
- Serves the React UI and the SSE stream at `GET /api/v1/stream`
- Accepts drawer execution requests at `POST /api/v1/node-execute`
- Queues commands for a resident agent
- Exposes agent polling at `POST /api/v1/agent/poll`
- Accepts task lifecycle updates at `POST /api/v1/agent/task-update`
- Serves local knowledge documents at `GET /api/v1/doc`
- Serves qmd-backed documents at `GET /api/v1/qmd-doc`
- Exports portable SOP bundles at `POST /api/v1/bundles/export`

### Resident OpenClaw agent
- Lives in `openclaw_agent.py`
- Sends heartbeats to `POST /api/v1/heartbeat`
- Polls the broker for queued node commands
- Reports `running`, `completed`, and `failed` task states
- Pushes knowledge artifacts back into the UI after execution
- Writes runtime cases and lessons into `agents/knowledge/`
- Triggers `qmd update` after new knowledge is written

## Local Development

### 1. Install dependencies

```bash
cd /Users/liumobei/.codex/worktrees/0721/text/skillstree-main
npm install
```

### 2. Start the web broker

```bash
npm run dev
```

Open the panel at [http://127.0.0.1:3000](http://127.0.0.1:3000).

### 3. Start the resident OpenClaw agent

In a second terminal:

```bash
cd /Users/liumobei/.codex/worktrees/0721/text/skillstree-main
python3 openclaw_agent.py
```

Or use:

```bash
npm run agent
```

When the agent is online, the Lobby HUD will switch from `WAITING FOR AGENT` to `AGENT LINKED`.

### 4. One-command launch

```bash
python3 start_app.py
```

This starts both:

- the broker
- the resident agent

and opens the Web console automatically.

## Handshake Smoke Test

1. Start the web broker.
2. Start `openclaw_agent.py`.
3. Open the UI and enter the skill tree.
4. Click any level-3 node and fill required inputs.
5. Press `Execute SOP`.
6. Watch the lobby HUD show the queued and running task.
7. Watch the node return to `idle` or `error`.
8. Check `Recent` and search for the runtime case in global knowledge search.

## Knowledge System

The console now uses a multi-source knowledge layer:

- seed/runtime knowledge
- scanned workspace docs
- `agents/knowledge/**/*.md`
- `qmd` search results

Runtime execution writes knowledge back into:

- `agents/knowledge/cases/`
- `agents/knowledge/runtime-lessons/`

and then runs:

```bash
qmd update
```

to keep the index fresh.

## Portable SOP Bundles

Every level-3 SOP can now be exported as a portable OpenClaw capability package.

### From the UI

1. Open the skill tree.
2. Click a level-3 SOP.
3. In the drawer footer, click `Export Bundle`.
4. Download the generated zip from the drawer.

### From the CLI

Export one SOP:

```bash
python3 scripts/export_sop_bundle.py --node-id sop-content-schedule-planning
```

Export all level-3 SOP bundles and generate an index:

```bash
python3 scripts/export_sop_bundle.py --all
```

Generated artifacts are written to:

- `exports/bundles/*.zip`
- `exports/bundles/index.json`

Each bundle contains:

- `capability-manifest.json`
- `dependency-hints.json`
- `README.md`
- `OPENCLAW.md`
- `install.py`
- `healthcheck.py`
- packaged `sops/`
- packaged `skills/` when local skill assets exist
- packaged `knowledge/` and `scripts/` when available

### Installing On A New OpenClaw

1. Unzip the exported bundle.
2. Run `python3 install.py`.
3. If dependencies are missing, install them one by one according to `dependency-hints.json`.
4. Run `python3 healthcheck.py`.
5. Start the resident OpenClaw agent on the new machine.

## Notes

- Prefer `http://127.0.0.1:3000` over `localhost` for local access stability.
- Some descriptive SOPs still need deeper execution adapters.
- The strongest currently-working file SOPs are:
  - `自动整理归档`
  - `资料清单化与索引`

## Tech Stack

- React 19
- Vite
- TypeScript
- Tailwind CSS
- React Flow (`@xyflow/react`)
- Framer Motion
- Spline (`@splinetool/react-spline`)
- Express broker + SSE
